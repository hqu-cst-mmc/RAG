# WPS Conversion And Embedded OCR Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Parse `.wps` files through Word COM conversion and OCR images embedded in the converted `.docx`.

**Architecture:** Extend `MaterialParser` without changing the scanner or workflow. Legacy Word conversion returns rows extracted from the temporary `.docx`; `.docx` parsing optionally appends OCR rows for `word/media/` images. Failures remain isolated by the existing per-material exception boundary.

**Tech Stack:** Python, pywin32 Word COM, ZIP/XML parsing, RapidOCR, pytest.

---

### Task 1: Add Parser Regression Tests

**Files:**
- Modify: `tests/test_scanner_and_parsers.py`

- [x] Add a test proving `.wps` uses `_convert_legacy_word_to_docx`.
- [x] Add a test proving embedded `.docx` images produce OCR chunks when OCR is enabled.
- [x] Add a test proving embedded image OCR is skipped when OCR is disabled.
- [x] Run targeted tests and confirm the new cases fail before implementation.

### Task 2: Implement Conversion And Embedded OCR

**Files:**
- Modify: `rag_eval/parsers.py`

- [x] Remove the unconditional `.wps` rejection.
- [x] Extract Word COM conversion into `_convert_legacy_word_to_docx`.
- [x] Extend `_parse_docx` to append OCR results from `word/media/`.
- [x] Use a temporary extracted image and the existing OCR cache behavior.
- [x] Run targeted tests until green.

### Task 3: Verify And Document

**Files:**
- Modify: `README.md`

- [x] Explain `.wps` conversion and fallback behavior.
- [x] Run the full pytest suite.
- [x] Run `compileall`.
