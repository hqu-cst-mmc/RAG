from __future__ import annotations

from pathlib import Path

from rag_eval.cli import build_parser, default_output_dir
from rag_eval.exporters import site_workbook_filename
from rag_eval.scanner import scan_materials


def test_cli_accepts_documented_evaluate_command() -> None:
    parser = build_parser()

    args = parser.parse_args(
        [
            "evaluate",
            "--site-dir",
            "材料目录",
            "--site-id",
            "山村-01",
            "--allow-sensitive-upload",
        ]
    )

    assert args.command == "evaluate"
    assert args.site_dir == Path("材料目录")
    assert args.site_id == "山村-01"
    assert args.allow_sensitive_upload is True


def test_default_output_dir_contains_site_id_and_run_id(tmp_path: Path) -> None:
    output = default_output_dir(tmp_path, "山村-01", "run-001")

    assert output == tmp_path / "outputs" / "山村-01" / "run-001"


def test_site_workbook_filename_uses_site_id_and_replaces_windows_invalid_characters() -> None:
    assert site_workbook_filename("山村-01") == "山村-01.xlsx"
    assert site_workbook_filename("山村:01/复合") == "山村_01_复合.xlsx"


def test_real_taozhou_material_library_scans_without_macos_metadata() -> None:
    root = (
        Path(__file__).parents[1]
        / "桃舟乡应急管理站"
        / "桃舟乡应急管理站"
        / "应急管理站（桃舟）"
    )
    if not root.exists():
        return

    materials = scan_materials(root)

    assert len(materials) > 300
    assert all("__MACOSX" not in item.relative_path for item in materials)
    assert all(not Path(item.relative_path).name.startswith("._") for item in materials)
