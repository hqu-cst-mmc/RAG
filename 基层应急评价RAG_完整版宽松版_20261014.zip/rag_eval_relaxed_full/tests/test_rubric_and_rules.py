from __future__ import annotations

from rag_eval.models import EvidenceItem, ScoreItem
from rag_eval.rubric import load_rubric
from rag_eval.rules import apply_score_caps, calculate_indices, classify_c39


def evidence(
    indicator_id: str,
    summary: str,
    evidence_type: str = "其他",
    *,
    found: str = "是",
    strength: str = "中",
) -> EvidenceItem:
    return EvidenceItem(
        indicator_id=indicator_id,
        indicator_name=indicator_id,
        found=found,
        summary=summary,
        sources=["材料.docx：第一节"],
        evidence_type=evidence_type,
        strength=strength,
        needs_review=False,
        missing_materials="",
    )


def score(indicator_id: str, value: int | None) -> ScoreItem:
    return ScoreItem(
        indicator_id=indicator_id,
        indicator_name=indicator_id,
        raw_score=value,
        fuzzy_score=None if value is None else {0: 0.0, 1: 0.33, 2: 0.67, 3: 1.0}[value],
        reason="模型初步建议",
        evidence_summary="",
        sources=[],
        strength="中",
        confidence="中",
        needs_review=False,
        improvement_materials="",
    )


def test_rubric_has_all_indicators_and_secondary_groups() -> None:
    rubric = load_rubric()
    assert list(rubric.indicators) == [f"C{i}" for i in range(1, 40)]
    assert list(rubric.secondary_groups) == [f"B{i}" for i in range(1, 12)]
    assert rubric.secondary_groups["B1"] == ["C1", "C2", "C3", "C4"]
    assert rubric.secondary_groups["B11"] == ["C36", "C37", "C38"]
    assert {item.indicator_id for item in rubric.score_caps} == {
        "C5", "C6", "C7", "C8", "C12", "C19", "C29", "C33", "C35"
    }


def test_score_caps_apply_conservative_rules_and_log_hits() -> None:
    items = {
        "C5": score("C5", 3),
        "C19": score("C19", 3),
        "C33": score("C33", 3),
    }
    evidence_map = {
        "C5": evidence("C5", "设有一般工作台账"),
        "C19": evidence("C19", "开展安全宣传活动", "宣传材料"),
        "C33": evidence("C33", "演练现场照片", "照片截图"),
    }

    capped, hits = apply_score_caps(items, evidence_map)

    assert capped["C5"].raw_score == 1
    assert capped["C19"].raw_score == 1
    assert capped["C33"].raw_score == 1
    assert {hit.indicator_id for hit in hits} == {"C5", "C19", "C33"}
    assert all(item.needs_review for item in capped.values())


def test_score_caps_normalize_fuzzy_value_from_raw_score() -> None:
    item = score("C1", 2)
    item.fuzzy_score = 1.0

    normalized, _hits = apply_score_caps({"C1": item}, {})

    assert normalized["C1"].fuzzy_score == 0.67


def test_score_caps_replace_na_and_award_one_point_for_explicit_scattered_evidence() -> None:
    items = {
        "C1": score("C1", None),
        "C2": score("C2", 0),
        "C3": score("C3", 0),
    }
    evidence_map = {
        "C1": evidence("C1", "材料不足", found="不确定", strength="无"),
        "C2": evidence("C2", "开展过一次预警宣传活动", strength="弱"),
        "C3": evidence("C3", "未找到相关材料", found="否", strength="无"),
    }

    normalized, _hits = apply_score_caps(items, evidence_map)

    assert normalized["C1"].raw_score == 0
    assert normalized["C1"].fuzzy_score == 0.0
    assert normalized["C2"].raw_score == 1
    assert normalized["C2"].fuzzy_score == 0.33
    assert normalized["C3"].raw_score == 0


def test_relaxed_version_awards_one_point_for_uncertain_weak_related_evidence() -> None:
    items = {
        "C33": score("C33", 0),
        "C18": score("C18", 0),
        "C5": score("C5", 0),
    }
    evidence_map = {
        "C33": evidence(
            "C33",
            "仅发现南金小学消防应急疏散演练照片，能弱关联到演练组织与应急准备",
            evidence_type="照片截图",
            found="不确定",
            strength="弱",
        ),
        "C18": evidence(
            "C18",
            "照片显示消防应急疏散演练场景，可弱关联安全宣传教育",
            evidence_type="照片截图",
            found="不确定",
            strength="弱",
        ),
        "C5": evidence("C5", "未找到重点人群清单或相关对象", found="否", strength="无"),
    }

    normalized, _hits = apply_score_caps(items, evidence_map)

    assert normalized["C33"].raw_score == 1
    assert normalized["C33"].needs_review is True
    assert "宽松版" in normalized["C33"].reason
    assert normalized["C18"].raw_score == 1
    assert normalized["C5"].raw_score == 0


def test_indices_treat_unexpected_na_as_zero_and_return_normalized_values() -> None:
    rubric = load_rubric()
    scores = {f"C{i}": score(f"C{i}", 3) for i in range(1, 39)}
    scores["C2"] = score("C2", None)
    scores["C3"] = score("C3", 1)

    result = calculate_indices(scores, rubric)

    assert result.secondary_scores["B1"] == 7 / 4
    assert result.pv_raw is not None
    assert result.mc_raw == 3.0
    assert result.mc_normalized == 1.0


def test_c39_records_incomplete_official_score_for_manual_review() -> None:
    incomplete = classify_c39(official_score=95)

    assert incomplete.official_score == 95
    assert incomplete.reference_kind == "SB"
    assert incomplete.reference_value is None
    assert incomplete.usable_as_external_reference is False


def test_c39_supports_score_grade_sbe_and_missing() -> None:
    official = classify_c39(official_score=95, max_score=100)
    grade = classify_c39(official_grade="良好")
    sbe = classify_c39(materials_detailed=True)
    missing = classify_c39()

    assert official.status == "有完整官方分数"
    assert official.reference_value == 0.95
    assert grade.status == "只有等级"
    assert grade.reference_value == 0.75
    assert sbe.status == "没有验收表但材料翔实"
    assert sbe.reference_kind == "SBe"
    assert sbe.reference_value is None
    assert missing.status == "没有验收表且材料不足"
