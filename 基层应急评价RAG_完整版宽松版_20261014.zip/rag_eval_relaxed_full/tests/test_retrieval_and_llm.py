from __future__ import annotations

from urllib.error import URLError

import pytest

from rag_eval.llm import DeepSeekClient
from rag_eval.models import Chunk, EvidenceItem
from rag_eval.retrieval import FastEmbedQdrantBackend, HybridRetriever, reciprocal_rank_fusion


def chunk(chunk_id: str, text: str, path: str = "材料.docx") -> Chunk:
    return Chunk(
        id=chunk_id,
        material_id=f"material-{chunk_id}",
        relative_path=path,
        text=text,
        locator="段落 1",
        material_type="制度文本",
    )


def test_keyword_retrieval_returns_relevant_source_without_optional_vector_dependencies() -> None:
    retriever = HybridRetriever(
        [
            chunk("a", "桃舟乡建立重点人群清单和责任联系人制度", "重点人员清单.xlsx"),
            chunk("b", "应急物资储备仓库管理制度", "物资制度.docx"),
            chunk("c", "安全生产宣传活动照片", "宣传照片.jpg"),
        ],
        enable_vector=False,
    )

    results = retriever.retrieve("重点人群联系人", limit=2)

    assert results[0].chunk.id == "a"
    assert results[0].score > results[1].score


def test_keyword_retrieval_uses_bm25_when_dependency_is_installed() -> None:
    pytest.importorskip("rank_bm25")

    retriever = HybridRetriever([chunk("a", "重点人群清单"), chunk("b", "物资储备")], enable_vector=False)

    assert retriever._bm25 is not None


def test_rrf_merges_keyword_and_vector_rankings() -> None:
    fused = reciprocal_rank_fusion([["a", "b"], ["b", "c"]], rank_constant=1)

    assert fused[0][0] == "b"
    assert dict(fused)["b"] == 1 / 3 + 1 / 2


def test_qdrant_backend_uses_current_query_points_api() -> None:
    class Vector:
        def tolist(self):
            return [0.1, 0.2]

    class Embedder:
        def query_embed(self, _query):
            return iter([Vector()])

    class Point:
        payload = {"chunk_id": "chunk-a"}

    class Response:
        points = [Point()]

    class Client:
        def query_points(self, **kwargs):
            assert kwargs == {
                "collection_name": "chunks",
                "query": [0.1, 0.2],
                "limit": 3,
            }
            return Response()

    backend = object.__new__(FastEmbedQdrantBackend)
    backend.client = Client()
    backend.embedder = Embedder()
    backend.collection_name = "chunks"

    assert backend.search("重点人群", 3) == ["chunk-a"]


def test_deepseek_client_retries_invalid_json_until_schema_validates() -> None:
    responses = iter(
        [
            {"choices": [{"message": {"content": "{\"indicator_id\":\"C5\"}"}}]},
            {
                "choices": [
                    {
                        "message": {
                            "content": """
                            {
                              "indicator_id": "C5",
                              "indicator_name": "重点人群清单建立",
                              "found": "是",
                              "summary": "存在威胁人员清单",
                              "sources": ["清单.xls：工作表1"],
                              "evidence_type": "台账清单",
                              "strength": "强",
                              "needs_review": false,
                              "missing_materials": ""
                            }
                            """
                        }
                    }
                ]
            },
        ]
    )
    calls: list[dict] = []

    def transport(payload: dict) -> dict:
        calls.append(payload)
        return next(responses)

    client = DeepSeekClient(api_key="test-key", transport=transport, max_attempts=2)
    result = client.complete_json("system", "user", EvidenceItem)

    assert result.indicator_id == "C5"
    assert len(calls) == 2
    assert "校验失败" in calls[1]["messages"][-1]["content"]


def test_deepseek_client_retries_transient_network_errors() -> None:
    calls = 0

    def transport(_payload: dict) -> dict:
        nonlocal calls
        calls += 1
        if calls == 1:
            raise URLError("[SSL: UNEXPECTED_EOF_WHILE_READING] EOF occurred in violation of protocol")
        return {
            "choices": [
                {
                    "message": {
                        "content": """
                        {
                          "indicator_id": "C1",
                          "indicator_name": "风险隐患提前识别",
                          "found": "否",
                          "summary": "",
                          "sources": [],
                          "evidence_type": "其他",
                          "strength": "无",
                          "needs_review": true,
                          "missing_materials": "隐患排查台账"
                        }
                        """
                    }
                }
            ]
        }

    result = DeepSeekClient(api_key="test-key", transport=transport, max_attempts=2).complete_json(
        "system", "user", EvidenceItem
    )

    assert calls == 2
    assert result.indicator_id == "C1"


def test_deepseek_client_never_serializes_api_key_into_payload() -> None:
    captured: list[dict] = []

    def transport(payload: dict) -> dict:
        captured.append(payload)
        return {
            "choices": [
                {
                    "message": {
                        "content": """
                        {
                          "indicator_id": "C1",
                          "indicator_name": "风险隐患提前识别",
                          "found": "否",
                          "summary": "",
                          "sources": [],
                          "evidence_type": "其他",
                          "strength": "无",
                          "needs_review": true,
                          "missing_materials": "隐患排查台账"
                        }
                        """
                    }
                }
            ]
        }

    DeepSeekClient(api_key="secret-value", transport=transport).complete_json(
        "system", "user", EvidenceItem
    )

    assert "secret-value" not in repr(captured)


def test_deepseek_client_includes_requested_json_schema_in_prompt() -> None:
    captured: list[dict] = []

    def transport(payload: dict) -> dict:
        captured.append(payload)
        return {
            "choices": [
                {
                    "message": {
                        "content": """
                        {
                          "indicator_id": "C1",
                          "indicator_name": "风险隐患提前识别",
                          "found": "否",
                          "summary": "",
                          "sources": [],
                          "evidence_type": "其他",
                          "strength": "无",
                          "needs_review": true,
                          "missing_materials": "隐患排查台账"
                        }
                        """
                    }
                }
            ]
        }

    DeepSeekClient(api_key="test-key", transport=transport).complete_json("system", "user", EvidenceItem)

    assert "indicator_id" in captured[0]["messages"][0]["content"]
    assert "JSON Schema" in captured[0]["messages"][0]["content"]
