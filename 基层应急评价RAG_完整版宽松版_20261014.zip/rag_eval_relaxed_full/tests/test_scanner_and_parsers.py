from __future__ import annotations

import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from openpyxl import Workbook

from rag_eval.ocr import OCRResult
from rag_eval.parsers import MaterialParser, parse_materials
from rag_eval.rubric import load_rubric
from rag_eval.scanner import assess_completeness, scan_materials


def write_docx(path: Path, paragraphs: list[str]) -> None:
    body = "".join(
        f"<w:p><w:r><w:t>{paragraph}</w:t></w:r></w:p>" for paragraph in paragraphs
    )
    xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f"<w:body>{body}</w:body></w:document>"
    )
    with ZipFile(path, "w", ZIP_DEFLATED) as archive:
        archive.writestr("word/document.xml", xml)


def write_docx_with_image(path: Path, paragraphs: list[str]) -> None:
    write_docx(path, paragraphs)
    with ZipFile(path, "a", ZIP_DEFLATED) as archive:
        archive.writestr("word/media/image1.png", b"fake embedded image")


class FakeOCREngine:
    def __init__(self) -> None:
        self.calls = 0

    def extract(self, path: Path) -> OCRResult:
        self.calls += 1
        return OCRResult(text="应急物资台账", confidence=0.91)


class FailingOCREngine:
    def extract(self, path: Path) -> OCRResult:
        raise RuntimeError(f"OCR unavailable for {path.name}")


def test_scan_ignores_macos_metadata_and_marks_duplicates(tmp_path: Path) -> None:
    (tmp_path / "制度").mkdir()
    (tmp_path / "__MACOSX").mkdir()
    (tmp_path / "制度" / "职责.txt").write_text("工作职责", encoding="utf-8")
    (tmp_path / "制度" / "职责副本.txt").write_text("工作职责", encoding="utf-8")
    (tmp_path / "__MACOSX" / "ignored.txt").write_text("ignored", encoding="utf-8")
    (tmp_path / "._ignored.docx").write_text("ignored", encoding="utf-8")
    (tmp_path / "~$临时锁文件.docx").write_text("ignored", encoding="utf-8")

    materials = scan_materials(tmp_path)

    assert len(materials) == 2
    assert sum(item.duplicate_of is not None for item in materials) == 1
    assert all("__MACOSX" not in item.relative_path for item in materials)


def test_scan_excludes_reference_rubric_document(tmp_path: Path) -> None:
    (tmp_path / "基层应急公共服务公共价值生成评价赋值大纲.docx").write_text(
        "规则文本不得成为站点证据",
        encoding="utf-8",
    )
    (tmp_path / "站点总结.txt").write_text("站点运行材料", encoding="utf-8")

    materials = scan_materials(tmp_path)

    assert [item.relative_path for item in materials] == ["站点总结.txt"]


def test_parser_preserves_docx_paragraph_and_xlsx_row_locators(tmp_path: Path) -> None:
    write_docx(tmp_path / "预案.docx", ["第一条 预警叫应", "第二条 人员转移"])
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "重点人员"
    sheet.append(["姓名", "联系人"])
    sheet.append(["张某", "李某"])
    workbook.save(tmp_path / "清单.xlsx")
    materials = scan_materials(tmp_path)

    chunks, parsed = parse_materials(tmp_path, materials, MaterialParser())

    assert any(chunk.locator == "段落 1" and "预警叫应" in chunk.text for chunk in chunks)
    assert any(chunk.locator == "工作表 重点人员 行 2" and "张某" in chunk.text for chunk in chunks)
    assert all(item.status == "parsed" for item in parsed)


def test_image_ocr_is_cached_and_video_is_registered_without_chunks(tmp_path: Path) -> None:
    (tmp_path / "台账截图.png").write_bytes(b"fake image")
    (tmp_path / "演练视频.mp4").write_bytes(b"fake video")
    engine = FakeOCREngine()
    parser = MaterialParser(ocr_engine=engine, ocr_cache_dir=tmp_path / ".ocr-cache")

    first_chunks, first_materials = parse_materials(tmp_path, scan_materials(tmp_path), parser)
    second_chunks, _ = parse_materials(tmp_path, scan_materials(tmp_path), parser)

    assert engine.calls == 1
    assert any(chunk.text == "应急物资台账" for chunk in first_chunks)
    assert any(chunk.text == "应急物资台账" for chunk in second_chunks)
    video = next(item for item in first_materials if item.extension == ".mp4")
    assert video.status == "registered"


def test_site_without_images_never_loads_ocr_engine(tmp_path: Path) -> None:
    (tmp_path / "制度.txt").write_text("值班制度", encoding="utf-8")
    parser = MaterialParser(ocr_engine=FailingOCREngine(), enable_ocr=True)

    chunks, materials = parse_materials(tmp_path, scan_materials(tmp_path), parser)

    assert [chunk.text for chunk in chunks] == ["值班制度"]
    assert materials[0].status == "parsed"


def test_image_ocr_failure_does_not_block_text_materials(tmp_path: Path) -> None:
    (tmp_path / "制度.txt").write_text("值班制度", encoding="utf-8")
    (tmp_path / "现场照片.jpg").write_bytes(b"fake image")
    parser = MaterialParser(ocr_engine=FailingOCREngine(), enable_ocr=True)

    chunks, materials = parse_materials(tmp_path, scan_materials(tmp_path), parser)

    assert [chunk.text for chunk in chunks] == ["值班制度"]
    image = next(item for item in materials if item.extension == ".jpg")
    assert image.status == "unparsed"
    assert "OCR unavailable" in (image.error or "")


def test_default_ocr_engine_is_reused_for_multiple_images(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "图片1.jpg").write_bytes(b"image one")
    (tmp_path / "图片2.jpg").write_bytes(b"image two")
    created: list[FakeOCREngine] = []

    def factory() -> FakeOCREngine:
        engine = FakeOCREngine()
        created.append(engine)
        return engine

    monkeypatch.setattr("rag_eval.parsers.RapidOCREngine", factory)
    parser = MaterialParser(enable_ocr=True)

    chunks, _materials = parse_materials(tmp_path, scan_materials(tmp_path), parser)

    assert len(chunks) == 2
    assert len(created) == 1
    assert created[0].calls == 2


def test_wps_uses_office_conversion_and_ocrs_embedded_images(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "应急广播照片.wps").write_bytes(b"wps placeholder")
    fixture_dir = tmp_path / ".fixture"
    fixture_dir.mkdir()
    converted = fixture_dir / "converted.docx"
    write_docx_with_image(converted, ["应急广播点位说明"])
    engine = FakeOCREngine()
    parser = MaterialParser(ocr_engine=engine, ocr_cache_dir=tmp_path / ".ocr-cache")
    monkeypatch.setattr(
        parser,
        "_convert_legacy_word_to_docx",
        lambda _source, target: shutil.copyfile(converted, target),
    )

    chunks, materials = parse_materials(tmp_path, scan_materials(tmp_path), parser)

    assert any(chunk.text == "应急广播点位说明" for chunk in chunks)
    assert any(chunk.text == "应急物资台账" and chunk.locator == "内嵌图片 image1.png" for chunk in chunks)
    assert engine.calls == 1
    wps = next(item for item in materials if item.extension == ".wps")
    assert wps.status == "parsed"
    assert wps.parser == "office-com"


def test_wps_conversion_skips_embedded_image_ocr_when_ocr_is_disabled(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "应急广播照片.wps").write_bytes(b"wps placeholder")
    fixture_dir = tmp_path / ".fixture"
    fixture_dir.mkdir()
    converted = fixture_dir / "converted.docx"
    write_docx_with_image(converted, ["应急广播点位说明"])
    parser = MaterialParser(ocr_engine=FailingOCREngine(), enable_ocr=False)
    monkeypatch.setattr(
        parser,
        "_convert_legacy_word_to_docx",
        lambda _source, target: shutil.copyfile(converted, target),
    )

    chunks, materials = parse_materials(tmp_path, scan_materials(tmp_path), parser)

    assert [chunk.text for chunk in chunks] == ["应急广播点位说明"]
    wps = next(item for item in materials if item.extension == ".wps")
    assert wps.status == "parsed"


def test_wps_conversion_failure_does_not_block_text_materials(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "01.wps").write_bytes(b"wps placeholder")
    (tmp_path / "02.txt").write_text("值班制度", encoding="utf-8")
    parser = MaterialParser(enable_ocr=False)
    monkeypatch.setattr(
        parser,
        "_convert_legacy_word_to_docx",
        lambda _source, _target: (_ for _ in ()).throw(RuntimeError("Word conversion unavailable")),
    )

    chunks, materials = parse_materials(tmp_path, scan_materials(tmp_path), parser)

    assert [chunk.text for chunk in chunks] == ["值班制度"]
    wps = next(item for item in materials if item.extension == ".wps")
    assert wps.status == "unparsed"
    assert "Word conversion unavailable" in (wps.error or "")


def test_parse_materials_reports_progress_for_each_unique_material(tmp_path: Path) -> None:
    (tmp_path / "制度1.txt").write_text("值班制度", encoding="utf-8")
    (tmp_path / "制度2.txt").write_text("响应制度", encoding="utf-8")
    updates: list[tuple[int, int, str, str]] = []

    parse_materials(
        tmp_path,
        scan_materials(tmp_path),
        MaterialParser(),
        progress=lambda current, total, item: updates.append(
            (current, total, item.relative_path, item.status)
        ),
    )

    assert updates == [
        (1, 2, "制度1.txt", "parsed"),
        (2, 2, "制度2.txt", "parsed"),
    ]


def test_completeness_uses_success_rate_aspects_and_structured_material(tmp_path: Path) -> None:
    aspect_dirs = ["组织机构", "运行机制", "指挥平台", "队伍", "执法", "物资", "宣传", "演练"]
    for aspect in aspect_dirs:
        directory = tmp_path / aspect
        directory.mkdir()
        (directory / f"{aspect}台账.txt").write_text(f"{aspect}记录", encoding="utf-8")
    materials = scan_materials(tmp_path)
    _, parsed = parse_materials(tmp_path, materials, MaterialParser())

    result = assess_completeness(parsed, load_rubric())

    assert result.level == "高"
    assert result.success_rate == 1.0
    assert set(result.aspects) == set(aspect_dirs)
