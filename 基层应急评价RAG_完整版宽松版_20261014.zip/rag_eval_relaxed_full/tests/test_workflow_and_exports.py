from __future__ import annotations

import json
from pathlib import Path

import pytest
from openpyxl import load_workbook

from rag_eval.c39 import OfficialGradeExtraction, OfficialScoreCandidate
from rag_eval.models import EvidenceItem, ScoreItem
from rag_eval.workflow import (
    C39Draft,
    C39TableSelectionDraft,
    EvidenceBatch,
    EvaluationWorkflow,
    ScoreBatch,
    SiteProfileDraft,
)


class FakeStructuredLLM:
    model = "fake-model"

    def complete_json(self, _system_prompt: str, user_prompt: str, schema):
        payload = json.loads(user_prompt)
        if schema is SiteProfileDraft:
            return SiteProfileDraft(
                scenario_type="山村",
                major_risks=["地质灾害", "防汛"],
                explanation="材料包含地灾威胁人员清单和防汛预案。",
            )
        if schema is EvidenceBatch:
            return EvidenceBatch(
                items=[
                    EvidenceItem(
                        indicator_id=indicator["id"],
                        indicator_name=indicator["name"],
                        found="是",
                        summary=f"{indicator['name']}存在制度或台账记录",
                        sources=["制度台账.txt：文本"],
                        evidence_type="制度文本",
                        strength="中",
                        needs_review=False,
                        missing_materials="",
                    )
                    for indicator in payload["indicators"]
                ]
            )
        if schema is ScoreBatch:
            return ScoreBatch(
                items=[
                    ScoreItem(
                        indicator_id=indicator["id"],
                        indicator_name=indicator["name"],
                        raw_score=2,
                        fuzzy_score=0.67,
                        reason="存在明确制度或台账记录",
                        evidence_summary="制度或台账记录",
                        sources=["制度台账.txt：文本"],
                        strength="中",
                        confidence="中",
                        needs_review=False,
                        improvement_materials="补充闭环反馈记录",
                    )
                    for indicator in payload["indicators"]
                ]
            )
        if schema is C39Draft:
            return C39Draft(materials_detailed=True)
        raise AssertionError(f"Unexpected schema: {schema}")


class IncompleteC39LLM(FakeStructuredLLM):
    def complete_json(self, system_prompt: str, user_prompt: str, schema):
        if schema is C39Draft:
            return C39Draft(official_score=95)
        return super().complete_json(system_prompt, user_prompt, schema)


class EmptyAndZeroScoreLLM(FakeStructuredLLM):
    def complete_json(self, system_prompt: str, user_prompt: str, schema):
        if schema is ScoreBatch:
            payload = json.loads(user_prompt)
            return ScoreBatch(
                items=[
                    ScoreItem(
                        indicator_id=indicator["id"],
                        indicator_name=indicator["name"],
                        raw_score=None if indicator["id"] == "C1" else 0,
                        fuzzy_score=None,
                        reason="模型未充分识别零散证据",
                        evidence_summary="",
                        sources=[],
                        strength="弱",
                        confidence="低",
                        needs_review=False,
                        improvement_materials="补充运行记录",
                    )
                    for indicator in payload["indicators"]
                ]
            )
        return super().complete_json(system_prompt, user_prompt, schema)


class SelectingC39TableLLM(FakeStructuredLLM):
    def complete_json(self, system_prompt: str, user_prompt: str, schema):
        if schema is C39TableSelectionDraft:
            payload = json.loads(user_prompt)
            assert len(payload["candidates"]) == 2
            return C39TableSelectionDraft(
                selected_candidate_id="official.docx#table-1",
                explanation="附件1是乡镇街道站点评价表，附件2是村社区评价表。",
            )
        return super().complete_json(system_prompt, user_prompt, schema)


class UncertainC39TableLLM(FakeStructuredLLM):
    def complete_json(self, system_prompt: str, user_prompt: str, schema):
        if schema is C39TableSelectionDraft:
            return C39TableSelectionDraft(
                selected_candidate_id=None,
                explanation="两个附件都可能对应当前评价对象，无法唯一确认。",
            )
        return super().complete_json(system_prompt, user_prompt, schema)


def score_candidate(candidate_id: str, table_index: int, score: float) -> OfficialScoreCandidate:
    return OfficialScoreCandidate(
        candidate_id=candidate_id,
        official_score=score,
        max_score=100,
        source="official.docx",
        table_index=table_index,
        title=f"附件{table_index}",
        preview=[f"附件{table_index}评分内容"],
        method="subtotal_sum",
        station_scope_score=2,
        title_score=0,
    )


def create_site(directory: Path) -> None:
    for aspect in ["组织机构", "运行机制", "指挥平台", "队伍", "执法", "物资", "宣传", "演练"]:
        aspect_dir = directory / aspect
        aspect_dir.mkdir(parents=True)
        (aspect_dir / f"{aspect}制度台账.txt").write_text(
            f"{aspect}制度台账记录，地质灾害威胁人员清单，防汛预案。", encoding="utf-8"
        )






def test_workflow_generates_traceable_report_excel_json_and_log(tmp_path: Path) -> None:
    site_dir = tmp_path / "桃舟乡"
    create_site(site_dir)
    output_dir = tmp_path / "outputs" / "山村-01" / "run-001"
    workflow = EvaluationWorkflow(
        llm=FakeStructuredLLM(),
        enable_vector=False,
        enable_ocr=False,
    )

    state = workflow.evaluate(
        site_dir=site_dir,
        site_id="山村-01",
        site_name="桃舟乡应急管理站",
        output_dir=output_dir,
        allow_sensitive_upload=True,
        run_id="run-001",
    )

    assert len(state.evidence) == 38
    assert len(state.scores) == 38
    assert state.profile.scenario_type == "山村"
    assert state.profile.completeness == "高"
    assert state.indices is not None
    assert state.c39 is not None
    assert state.c39.reference_kind == "SBe"
    assert state.model_name == "fake-model"
    assert (output_dir / "report.md").exists()
    assert (output_dir / "山村-01.xlsx").exists()
    assert (output_dir / "result.json").exists()
    assert (output_dir / "run.log").exists()
    assert (output_dir / "checkpoint.json").exists()
    try:
        import langgraph.checkpoint.sqlite  # noqa: F401
    except ImportError:
        pass
    else:
        assert (output_dir / "langgraph-checkpoints.sqlite").exists()
    workbook = load_workbook(output_dir / "山村-01.xlsx", read_only=True)
    assert workbook.sheetnames == ["完整赋值表", "证据矩阵", "二级指标和综合指数", "人工复核清单"]
    report = (output_dir / "report.md").read_text(encoding="utf-8")
    assert "C39" in report
    assert "PV" in report


def test_workflow_requires_explicit_sensitive_upload_consent(tmp_path: Path) -> None:
    site_dir = tmp_path / "站点"
    site_dir.mkdir()
    workflow = EvaluationWorkflow(llm=FakeStructuredLLM(), enable_vector=False, enable_ocr=False)

    with pytest.raises(ValueError, match="allow-sensitive-upload"):
        workflow.evaluate(
            site_dir=site_dir,
            site_id="山村-01",
            output_dir=tmp_path / "outputs",
            allow_sensitive_upload=False,
        )


def test_workflow_rejects_reference_rubric_inside_site_directory(tmp_path: Path) -> None:
    site_dir = tmp_path / "data"
    site_dir.mkdir()
    (site_dir / "基层应急公共服务公共价值生成评价赋值大纲.docx").write_text(
        "规则文本不得成为站点证据",
        encoding="utf-8",
    )
    workflow = EvaluationWorkflow(llm=FakeStructuredLLM(), enable_vector=False, enable_ocr=False)

    with pytest.raises(ValueError, match="评价赋值大纲"):
        workflow.evaluate(
            site_dir=site_dir,
            site_id="错误目录",
            output_dir=tmp_path / "outputs",
            allow_sensitive_upload=True,
        )


def test_workflow_exports_report_when_c39_score_has_no_max_score(tmp_path: Path) -> None:
    site_dir = tmp_path / "站点"
    create_site(site_dir)
    output_dir = tmp_path / "outputs"
    workflow = EvaluationWorkflow(llm=IncompleteC39LLM(), enable_vector=False, enable_ocr=False)

    state = workflow.evaluate(
        site_dir=site_dir,
        site_id="山村-01",
        output_dir=output_dir,
        allow_sensitive_upload=True,
    )

    assert state.c39 is not None
    assert state.c39.status == "官方分数不完整"
    assert state.c39.reference_value is None
    assert state.c39.usable_as_external_reference is False
    assert (output_dir / "report.md").exists()
    assert (output_dir / "山村-01.xlsx").exists()


def test_workflow_uses_deterministic_official_assessment_score(tmp_path: Path, monkeypatch) -> None:
    site_dir = tmp_path / "站点"
    create_site(site_dir)
    output_dir = tmp_path / "outputs"
    workflow = EvaluationWorkflow(llm=FakeStructuredLLM(), enable_vector=False, enable_ocr=False)
    monkeypatch.setattr(
        "rag_eval.workflow.collect_official_score_candidates",
        lambda *_args: [score_candidate("official.docx#table-1", 1, 87)],
    )

    state = workflow.evaluate(
        site_dir=site_dir,
        site_id="新塘街道",
        output_dir=output_dir,
        allow_sensitive_upload=True,
    )

    assert state.c39 is not None
    assert state.c39.status == "有完整官方分数"
    assert state.c39.official_score == 87
    assert state.c39.max_score == 100
    assert state.c39.reference_value == 0.87
    assert "小计列" in state.c39.notes


def test_workflow_uses_deterministic_official_assessment_grade(tmp_path: Path, monkeypatch) -> None:
    site_dir = tmp_path / "站点"
    create_site(site_dir)
    output_dir = tmp_path / "outputs"
    workflow = EvaluationWorkflow(llm=FakeStructuredLLM(), enable_vector=False, enable_ocr=False)
    monkeypatch.setattr("rag_eval.workflow.collect_official_score_candidates", lambda *_args: [])
    monkeypatch.setattr(
        "rag_eval.workflow.extract_official_grade",
        lambda *_args: OfficialGradeExtraction(
            official_grade="良好",
            source="建设评分表.docx",
            method="explicit_comprehensive_grade",
        ),
    )

    state = workflow.evaluate(
        site_dir=site_dir,
        site_id="丰泽街道",
        output_dir=output_dir,
        allow_sensitive_upload=True,
    )

    assert state.c39 is not None
    assert state.c39.status == "只有等级"
    assert state.c39.official_grade == "良好"
    assert state.c39.reference_value == 0.75
    assert "综合评价勾选等级" in state.c39.notes


def test_workflow_asks_llm_to_select_one_of_multiple_official_score_tables(tmp_path: Path, monkeypatch) -> None:
    site_dir = tmp_path / "站点"
    create_site(site_dir)
    workflow = EvaluationWorkflow(llm=SelectingC39TableLLM(), enable_vector=False, enable_ocr=False)
    monkeypatch.setattr(
        "rag_eval.workflow.collect_official_score_candidates",
        lambda *_args: [
            score_candidate("official.docx#table-1", 1, 87),
            score_candidate("official.docx#table-2", 2, 99),
        ],
    )

    state = workflow.evaluate(
        site_dir=site_dir,
        site_id="新塘街道",
        output_dir=tmp_path / "outputs",
        allow_sensitive_upload=True,
    )

    assert state.c39 is not None
    assert state.c39.status == "有完整官方分数"
    assert state.c39.reference_value == 0.87
    assert "模型选表" in state.c39.notes
    assert "附件1是乡镇街道站点评价表" in state.c39.notes


def test_workflow_marks_multiple_official_score_tables_for_review_when_llm_cannot_choose(
    tmp_path: Path,
    monkeypatch,
) -> None:
    site_dir = tmp_path / "站点"
    create_site(site_dir)
    workflow = EvaluationWorkflow(llm=UncertainC39TableLLM(), enable_vector=False, enable_ocr=False)
    monkeypatch.setattr(
        "rag_eval.workflow.collect_official_score_candidates",
        lambda *_args: [
            score_candidate("official.docx#table-1", 1, 87),
            score_candidate("official.docx#table-2", 2, 99),
        ],
    )

    state = workflow.evaluate(
        site_dir=site_dir,
        site_id="待复核站点",
        output_dir=tmp_path / "outputs",
        allow_sensitive_upload=True,
    )

    assert state.c39 is not None
    assert state.c39.status == "多附件评分表待人工复核"
    assert state.c39.reference_value is None
    assert state.c39.usable_as_external_reference is False


def test_workflow_exports_only_numeric_c1_c38_scores(tmp_path: Path) -> None:
    site_dir = tmp_path / "站点"
    create_site(site_dir)
    output_dir = tmp_path / "outputs"
    workflow = EvaluationWorkflow(llm=EmptyAndZeroScoreLLM(), enable_vector=False, enable_ocr=False)

    state = workflow.evaluate(
        site_dir=site_dir,
        site_id="山村-01",
        output_dir=output_dir,
        allow_sensitive_upload=True,
    )

    assert all(item.raw_score in {0, 1, 2, 3} for item in state.scores.values())
    assert state.scores["C1"].raw_score == 1
    assert state.scores["C2"].raw_score == 1
    workbook = load_workbook(output_dir / "山村-01.xlsx", read_only=True)
    assignment_rows = list(workbook["完整赋值表"].iter_rows(values_only=True))
    raw_score_index = assignment_rows[0].index("原始分值")
    assert all(row[raw_score_index] != "NA" for row in assignment_rows[1:39])


def test_workflow_reports_stage_progress(tmp_path: Path) -> None:
    site_dir = tmp_path / "站点"
    create_site(site_dir)
    updates: list[str] = []
    workflow = EvaluationWorkflow(
        llm=FakeStructuredLLM(),
        enable_vector=False,
        enable_ocr=False,
        progress=updates.append,
    )

    workflow.evaluate(
        site_dir=site_dir,
        site_id="山村-01",
        output_dir=tmp_path / "outputs",
        allow_sensitive_upload=True,
    )

    assert any("扫描材料" in update for update in updates)
    assert any("解析进度" in update for update in updates)
    assert any("证据提取" in update for update in updates)
    assert any("导出报告" in update for update in updates)
