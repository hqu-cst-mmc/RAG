from __future__ import annotations

import json
from pathlib import Path

from openpyxl import Workbook

from rag_eval.cli import build_parser
from rag_eval.models import EvidenceItem, RunState, ScoreItem, SiteProfile
from rag_eval.review import apply_review_results, review_score_delta
from rag_eval.rubric import load_rubric
from rag_eval.rules import calculate_indices


def score(indicator_id: str, value: int) -> ScoreItem:
    return ScoreItem(
        indicator_id=indicator_id,
        indicator_name=indicator_id,
        raw_score=value,
        fuzzy_score={0: 0.0, 1: 0.33, 2: 0.67, 3: 1.0}[value],
        reason="模型初评",
        evidence_summary="",
        sources=[],
        strength="弱",
        confidence="中",
        needs_review=False,
        improvement_materials="",
    )


def evidence(indicator_id: str) -> EvidenceItem:
    return EvidenceItem(
        indicator_id=indicator_id,
        indicator_name=indicator_id,
        found="不确定",
        summary="待复核",
        sources=[],
        evidence_type="其他",
        strength="弱",
        needs_review=True,
        missing_materials="",
    )


def write_state(path: Path, site_id: str) -> None:
    scores = {f"C{i}": score(f"C{i}", 0) for i in range(1, 39)}
    scores["C2"] = score("C2", 1)
    scores["C3"] = score("C3", 3)
    scores["C4"] = score("C4", 2)
    evidences = {f"C{i}": evidence(f"C{i}") for i in range(1, 39)}
    state = RunState(
        run_id="run-001",
        model_name="test-model",
        site_dir=str(path),
        output_dir=str(path),
        profile=SiteProfile(site_id=site_id, site_name=site_id),
        evidence=evidences,
        scores=scores,
        indices=calculate_indices(scores, load_rubric()),
    )
    path.mkdir(parents=True)
    (path / "result.json").write_text(
        json.dumps(state.model_dump(mode="json"), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def write_review_workbook(path: Path) -> None:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "人工复核清单"
    sheet.append(["站点编号", "指标编号", "当前分值", "复核原因", "建议补充材料", "是否必须复核", "复核结果"])
    sheet.append(["站点A", "C1", 0, "", "", "否", "有材料"])
    sheet.append(["站点A", "C2", 1, "", "", "否", "有详细记录"])
    sheet.append(["站点A", "C3", 3, "", "", "否", "有报告"])
    sheet.append(["站点A", "C4", 2, "", "", "否", "没有材料"])
    workbook.save(path)


def test_review_score_delta_parses_manual_review_phrases() -> None:
    assert review_score_delta("有材料") == 1
    assert review_score_delta("有记录") == 1
    assert review_score_delta("有转移记录") == 1
    assert review_score_delta("有详细材料") == 2
    assert review_score_delta("详细记录") == 2
    assert review_score_delta("没有材料") == 0
    assert review_score_delta("") == 0


def test_cli_accepts_apply_review_command() -> None:
    args = build_parser().parse_args(
        [
            "apply-review",
            "--review-dir",
            "data/严格版0605",
            "--source-output-dir",
            "outputs/_batch/run/需要分析的资料",
            "--output-dir",
            "outputs/_reviewed/严格版0605",
        ]
    )

    assert args.command == "apply-review"
    assert args.review_dir == Path("data/严格版0605")


def test_apply_review_results_updates_scores_and_recalculates_indices(tmp_path: Path) -> None:
    review_dir = tmp_path / "reviews"
    source_dir = tmp_path / "source"
    output_dir = tmp_path / "reviewed"
    review_dir.mkdir()
    write_review_workbook(review_dir / "站点A.xlsx")
    write_state(source_dir / "站点A", "站点A")

    result = apply_review_results(
        review_dir=review_dir,
        source_output_dir=source_dir,
        output_dir=output_dir,
    )

    assert result.applied_updates == 3
    updated = json.loads((output_dir / "站点A" / "result.json").read_text(encoding="utf-8"))
    assert updated["scores"]["C1"]["raw_score"] == 1
    assert updated["scores"]["C2"]["raw_score"] == 3
    assert updated["scores"]["C3"]["raw_score"] == 3
    assert updated["scores"]["C4"]["raw_score"] == 2
    assert "人工复核回写" in updated["scores"]["C1"]["reason"]
    assert updated["indices"]["secondary_scores"]["B1"] == 2.25
    assert (output_dir / "apply-review-result.json").exists()
