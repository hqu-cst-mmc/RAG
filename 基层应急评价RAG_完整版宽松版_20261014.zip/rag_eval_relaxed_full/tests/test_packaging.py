from __future__ import annotations

from pathlib import Path


def test_full_dependencies_pin_verified_onnxruntime_version() -> None:
    pyproject = (Path(__file__).parents[1] / "pyproject.toml").read_text(encoding="utf-8")

    assert '"onnxruntime==1.23.2"' in pyproject


def test_full_dependencies_include_langgraph_sqlite_checkpointer() -> None:
    pyproject = (Path(__file__).parents[1] / "pyproject.toml").read_text(encoding="utf-8")

    assert '"langgraph-checkpoint-sqlite>=3.0"' in pyproject
