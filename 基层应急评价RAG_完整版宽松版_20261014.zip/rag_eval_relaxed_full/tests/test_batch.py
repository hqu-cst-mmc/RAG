from __future__ import annotations

import json
from pathlib import Path

from rag_eval.batch import discover_batch_sites, evaluate_batch
from rag_eval.cli import build_parser, run_evaluate_batch


def create_batch_tree(data_dir: Path) -> None:
    data_dir.mkdir(parents=True)
    (data_dir / "规则大纲.docx").write_text("根目录文件应忽略", encoding="utf-8")
    (data_dir / "县区甲").mkdir(parents=True)
    (data_dir / "县区甲" / "县区级说明.docx").write_text("县区根目录文件应忽略", encoding="utf-8")
    (data_dir / "县区甲" / "站点A" / "组织机构").mkdir(parents=True)
    (data_dir / "县区甲" / "站点A" / "组织机构" / "名单.txt").write_text("材料", encoding="utf-8")
    (data_dir / "县区甲" / "站点B").mkdir()
    (data_dir / "县区乙" / "站点C").mkdir(parents=True)


def test_cli_accepts_evaluate_batch_command() -> None:
    args = build_parser().parse_args(
        [
            "evaluate-batch",
            "--data-dir",
            "data",
            "--flat-sites",
            "--allow-sensitive-upload",
        ]
    )

    assert args.command == "evaluate-batch"
    assert args.data_dir == Path("data")
    assert args.flat_sites is True
    assert args.allow_sensitive_upload is True


def test_evaluate_batch_requires_explicit_sensitive_upload_consent(tmp_path: Path) -> None:
    args = build_parser().parse_args(["evaluate-batch", "--data-dir", str(tmp_path)])

    assert run_evaluate_batch(args) == 2


def test_discover_batch_sites_uses_exactly_region_and_site_directory_levels(tmp_path: Path) -> None:
    data_dir = tmp_path / "data"
    create_batch_tree(data_dir)

    sites = discover_batch_sites(data_dir)

    assert [(site.region_name, site.site_id, site.site_dir) for site in sites] == [
        ("县区乙", "站点C", data_dir / "县区乙" / "站点C"),
        ("县区甲", "站点A", data_dir / "县区甲" / "站点A"),
        ("县区甲", "站点B", data_dir / "县区甲" / "站点B"),
    ]


def test_discover_batch_sites_supports_flat_site_directories(tmp_path: Path) -> None:
    data_dir = tmp_path / "需要分析的资料"
    (data_dir / "池店").mkdir(parents=True)
    (data_dir / "池店" / "考核表.docx").write_text("材料", encoding="utf-8")
    (data_dir / "桃舟乡应急管理站" / "八大类材料").mkdir(parents=True)
    (data_dir / "根目录说明.docx").write_text("根目录文件应忽略", encoding="utf-8")

    sites = discover_batch_sites(data_dir, flat_sites=True)

    assert [(site.region_name, site.site_id, site.site_dir) for site in sites] == [
        ("需要分析的资料", "桃舟乡应急管理站", data_dir / "桃舟乡应急管理站"),
        ("需要分析的资料", "池店", data_dir / "池店"),
    ]


def test_evaluate_batch_continues_after_site_failure_and_writes_summary(tmp_path: Path) -> None:
    data_dir = tmp_path / "data"
    create_batch_tree(data_dir)
    output_dir = tmp_path / "outputs" / "_batch" / "run-001"
    calls: list[str] = []

    def evaluator(site_dir: Path, site_id: str, site_name: str, site_output_dir: Path) -> None:
        calls.append(site_id)
        if site_id == "站点B":
            raise RuntimeError("模拟失败")
        site_output_dir.mkdir(parents=True)
        (site_output_dir / f"{site_id}.xlsx").write_text("ok", encoding="utf-8")

    result = evaluate_batch(
        data_dir=data_dir,
        output_dir=output_dir,
        evaluator=evaluator,
        progress=lambda _message: None,
    )

    assert calls == ["站点C", "站点A", "站点B"]
    assert result.total_sites == 3
    assert result.succeeded == 2
    assert result.failed == 1
    assert result.items[2].status == "failed"
    assert result.items[2].error == "RuntimeError: 模拟失败"
    payload = json.loads((output_dir / "batch-result.json").read_text(encoding="utf-8"))
    assert payload["failed"] == 1
    assert (output_dir / "batch-report.md").exists()
