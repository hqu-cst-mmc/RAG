from __future__ import annotations

from pathlib import Path
from xml.sax.saxutils import escape
from zipfile import ZIP_DEFLATED, ZipFile

from rag_eval.c39 import collect_official_score_candidates, extract_official_grade, extract_official_score
from rag_eval.scanner import scan_materials


def _cell(text: str) -> str:
    return f"<w:tc><w:p><w:r><w:t>{escape(text)}</w:t></w:r></w:p></w:tc>"


def _row(*cells: str) -> str:
    return "<w:tr>" + "".join(_cell(cell) for cell in cells) + "</w:tr>"


def write_tables_docx(path: Path, tables: list[str], *, explicit_total: str = "") -> None:
    paragraph = f"<w:p><w:r><w:t>{escape(explicit_total)}</w:t></w:r></w:p>" if explicit_total else ""
    xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f"<w:body>{paragraph}{''.join(f'<w:tbl>{table}</w:tbl>' for table in tables)}</w:body>"
        "</w:document>"
    )
    with ZipFile(path, "w", ZIP_DEFLATED) as archive:
        archive.writestr("word/document.xml", xml)


def write_official_assessment_docx(
    path: Path,
    *,
    explicit_total: str = "",
    title: str = "乡镇（街道）标准化应急管理站建设情况评价表",
    include_village_attachment: bool = False,
) -> None:
    township_table = "".join(
        [
            _row(title),
            _row("八个有", "内容", "具体标准", "得分情况"),
            _row("", "", "", "占比", "小计"),
            _row("工作机构", "统一挂牌", "标准", "60分", "50"),
            _row("运行机制", "隐患闭环", "标准", "40分", "37"),
        ]
    )
    village_table = "".join(
        [
            _row("村（社区）“党建+网格+应急管理”建设情况评价表"),
            _row("五个有", "内容", "具体标准", "得分情况"),
            _row("", "", "", "占比", "小计"),
            _row("网格体系", "明确职责", "标准", "100分", "99"),
        ]
    )
    tables = [township_table, village_table] if include_village_attachment else [township_table]
    write_tables_docx(path, tables, explicit_total=explicit_total)


def test_extract_official_score_sums_township_assessment_subtotals(tmp_path: Path) -> None:
    write_official_assessment_docx(tmp_path / "创建考核表.docx")

    result = extract_official_score(tmp_path, scan_materials(tmp_path))

    assert result is not None
    assert result.official_score == 87
    assert result.max_score == 100
    assert result.method == "subtotal_sum"


def test_extract_official_score_prefers_explicit_total(tmp_path: Path) -> None:
    write_official_assessment_docx(tmp_path / "创建考核表.docx", explicit_total="填报单位：示例镇 总分：95分")

    result = extract_official_score(tmp_path, scan_materials(tmp_path))

    assert result is not None
    assert result.official_score == 95
    assert result.max_score == 100
    assert result.method == "explicit_total"


def test_extract_official_score_supports_city_year_township_title(tmp_path: Path) -> None:
    write_official_assessment_docx(
        tmp_path / "创建考核表.docx",
        title="晋江市2025年镇（街道）标准化应急管理站建设评价表",
    )

    result = extract_official_score(tmp_path, scan_materials(tmp_path))

    assert result is not None
    assert result.official_score == 87
    assert result.max_score == 100


def test_collect_official_score_candidates_preserves_multiple_attachments(tmp_path: Path) -> None:
    write_official_assessment_docx(
        tmp_path / "创建考核表.docx",
        include_village_attachment=True,
    )

    candidates = collect_official_score_candidates(tmp_path, scan_materials(tmp_path))

    assert [(candidate.table_index, candidate.official_score, candidate.max_score) for candidate in candidates] == [
        (1, 87, 100),
        (2, 99, 100),
    ]
    assert extract_official_score(tmp_path, scan_materials(tmp_path)) is None


def test_extract_official_score_uses_table_structure_when_title_changes(tmp_path: Path) -> None:
    write_official_assessment_docx(
        tmp_path / "创建考核表.docx",
        title="基层站点建设现场检查记录",
    )

    result = extract_official_score(tmp_path, scan_materials(tmp_path))

    assert result is not None
    assert result.official_score == 87
    assert result.max_score == 100


def test_extract_official_score_returns_none_for_conflicting_station_tables(tmp_path: Path) -> None:
    first = "".join(
        [
            _row("基层站点检查表甲"),
            _row("内容", "具体标准", "得分情况"),
            _row("", "", "占比", "小计"),
            _row("工作机构", "运行机制", "60分", "50"),
            _row("指挥通信", "物资宣传", "40分", "37"),
        ]
    )
    second = "".join(
        [
            _row("基层站点检查表乙"),
            _row("内容", "具体标准", "得分情况"),
            _row("", "", "占比", "小计"),
            _row("工作机构", "运行机制", "60分", "55"),
            _row("指挥通信", "物资宣传", "40分", "40"),
        ]
    )
    write_tables_docx(tmp_path / "创建考核表.docx", [first, second])

    result = extract_official_score(tmp_path, scan_materials(tmp_path))

    assert result is None


def test_extract_official_grade_reads_checked_comprehensive_grade(tmp_path: Path) -> None:
    grade_table = "".join(
        [
            _row("基层站点建设评分表"),
            _row("工作机构", "工作场所", "☑优秀□良好□合格"),
            _row("指挥通信", "运行机制", "□优秀☑良好□合格"),
            _row("执法队伍", "预案物资宣传", "☑优秀□良好□合格"),
            _row("综合评价", "□优秀☑良好□合格"),
        ]
    )
    write_tables_docx(tmp_path / "建设评分表.docx", [grade_table])

    result = extract_official_grade(tmp_path, scan_materials(tmp_path))

    assert result is not None
    assert result.official_grade == "良好"
    assert result.method == "explicit_comprehensive_grade"
