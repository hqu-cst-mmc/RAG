param([Parameter(ValueFromRemainingArguments=$true)][string[]]$RagArgs)
$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) { throw 'Run install.ps1 first.' }
& '.\.venv\Scripts\python.exe' -m rag_eval @RagArgs
exit $LASTEXITCODE
