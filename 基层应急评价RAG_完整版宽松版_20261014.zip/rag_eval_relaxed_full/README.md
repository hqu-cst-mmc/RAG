# 基层应急公共服务评价 RAG

本 ZIP 是独立的原版完整版宽松版。首次使用请先读 [交接与运行说明](交接与运行说明.md)，运行 `install.ps1` 安装依赖。已通过 59 项离线测试和安装包验证，详见 `交付验证.json`。

> 当前目录是“宽松酌情评分版”。它保留原版解析、OCR、检索、C39 和导出流程，但 C1-C38 评分口径更宽：材料中的照片、活动名称、文件名或场景内容只要与指标存在弱关联，也可以酌情给 1 分，并在理由中标记人工复核。2 分和 3 分仍要求较直接的制度、台账、记录、反馈或闭环证据。

`rag_eval` 是一个本地命令行 MVP。它从一个已解压的乡镇或站点材料目录中扫描文件，解析文档和表格，对图片执行可选本地 OCR，通过本地混合检索召回证据，再调用 DeepSeek 生成可人工复核的评价初稿。

评分口径由程序约束：C1-C38 仅使用 0-3 分，不输出 `NA`；C39 单独作为外部参照变量，B1-B11、PV 和 MC 使用确定性公式计算。官方考核高分不会直接推高 C1-C38。

C39 会先从官方考核材料中提取具备评分结构的表格候选。只有一个候选表时由代码直接计算；同一文件包含多个附件或存在多个候选表时，DeepSeek 只负责选择适用于当前乡镇或街道站点的附件，最终得分和满分仍由代码计算。模型无法唯一判断时，C39 标记为待人工复核，不自动写入 SB。

## 安装

建议使用官方 CPython 3.10 以上版本创建虚拟环境。Windows 上不要使用 Anaconda 基础解释器创建 OCR 和向量检索运行环境；Anaconda 的 DLL 搜索路径可能与 ONNX Runtime 冲突。

```powershell
py -3.12 -m venv .venv-runtime
.\.venv-runtime\Scripts\python.exe -m pip install -e ".[full,dev]"
.\.venv-runtime\Scripts\python.exe -m rag_eval init-models
```

`init-models` 首次运行会下载 RapidOCR 和 `BAAI/bge-small-zh-v1.5` 所需模型，后续复用本地缓存。

## 配置 DeepSeek

API Key 只从环境变量读取，不会写入结果文件：

```powershell
$env:DEEPSEEK_API_KEY = "替换为重新生成的Key"
$env:DEEPSEEK_BASE_URL = "https://api.deepseek.com"
$env:DEEPSEEK_MODEL = "deepseek-v4-pro"
```

此前在聊天中暴露过的 Key 应当先在 DeepSeek 控制台撤销并重新生成。

## 离线扫描

只列出材料，不调用云端模型：

```powershell
python -m rag_eval scan --site-dir ".\桃舟乡应急管理站\桃舟乡应急管理站\应急管理站（桃舟）"
```

同时解析文本材料，但暂不处理图片 OCR：

```powershell
python -m rag_eval scan --site-dir ".\站点目录" --parse --output-json ".\scan.json"
```

## 单站点评价

```powershell
python -m rag_eval evaluate `
  --site-dir ".\站点目录" `
  --site-id "山村-01" `
  --site-name "桃舟乡应急管理站" `
  --allow-sensitive-upload
```

`--allow-sensitive-upload` 是必须显式添加的确认项，因为候选材料片段可能包含个人信息。可使用 `--disable-vector` 或 `--disable-ocr` 关闭对应能力。

如果 `data` 目录同时保存多个县区材料和《基层应急公共服务公共价值生成评价赋值大纲.docx》，不要将整个 `data` 目录传给 `--site-dir`。评价大纲属于规则来源，不得成为任何站点的证据。请始终将 `--site-dir` 指向一个站点或一个明确的“站点 + 风险场景”评价单元目录，例如：

```powershell
python -m rag_eval evaluate `
  --site-dir ".\data\磁灶镇" `
  --site-id "磁灶镇" `
  --site-name "磁灶镇" `
  --allow-sensitive-upload
```

`evaluate` 命令只处理单个评价单元。包含多个乡镇或街道的县区目录不要直接传给 `--site-dir`；如需一次处理全部已整理站点，请使用下方的 `evaluate-batch` 命令。

默认输出目录为 `outputs/<站点编号>/<时间戳>/`：

- `report.md`：完整评价报告和四张 Markdown 表。
- `<站点编号>.xlsx`：四张 Excel 工作表，例如 `磁灶镇.xlsx`。
- `result.json`：结构化结果与规则命中记录。
- `run.log`：解析失败、依赖回退和人工复核提示。
- `checkpoint.json`：节点状态快照，用于审计和恢复。
- `langgraph-checkpoints.sqlite`：LangGraph 本地 SQLite checkpoint。

## 批量评价

当 `data` 已按 `data/<县区市>/<站点>/` 整理后，可以批量评价全部站点：

```powershell
python -m rag_eval evaluate-batch `
  --data-dir ".\data" `
  --allow-sensitive-upload
```

批处理严格只将第二层文件夹识别为站点。例如 `data/晋江市/新塘街道/` 是一个站点；更深层的材料分类文件夹不会被单独评价。`data` 根目录和县区市根目录中的散落文件会被忽略。

如果材料已整理为第一层就是站点，例如 `data/需要分析的资料/池店/`、`data/需要分析的资料/桃舟乡应急管理站/`，请增加 `--flat-sites`：

```powershell
python -m rag_eval evaluate-batch `
  --data-dir ".\data\需要分析的资料" `
  --flat-sites `
  --allow-sensitive-upload
```

启用 `--flat-sites` 后，程序只将 `--data-dir` 下的第一层文件夹识别为站点；站点内部的八大类材料文件夹不会被单独评价。

默认输出目录为 `outputs/_batch/<时间戳>/`。每个站点仍然单独生成报告、Excel、JSON、日志和 checkpoint。某个站点失败时，其余站点会继续处理；批次目录中会额外生成：

- `batch-report.md`：成功与失败站点清单。
- `batch-result.json`：结构化批次结果。

## 人工复核回写

如果人工在各站点 Excel 的“人工复核清单”中新增并填写了 `复核结果` 列，可以将复核意见回写到原评价结果，重新计算 B1-B11、PV 和 MC，并重新导出报告：

```powershell
python -m rag_eval apply-review `
  --review-dir ".\data\严格版0605" `
  --source-output-dir ".\outputs\_batch\20260604-160120\需要分析的资料" `
  --output-dir ".\outputs\_reviewed\严格版0605"
```

回写规则：`有材料`、`有记录`、`有报告`、`有转移记录` 及类似以“有”开头的复核结果加 1 分；包含 `详细` 的复核结果加 2 分；最高封顶为 3 分；`没有材料`、`无记录` 等否定表述不加分。输出目录中会生成更新后的站点报告、Excel、JSON，以及 `apply-review-report.md` 和 `apply-review-result.json`。

## 格式支持

- 直接解析：`.docx`、`.docm`、`.xlsx`、`.pdf`、`.txt`、`.md`、`.csv`、`.tsv`。
- 可选依赖：`.xls` 使用 `xlrd`，图片使用 RapidOCR。
- Windows 回退：`.doc` 和 `.wps` 尝试通过本机 Microsoft Word COM 转换为临时 `.docx`。转换后的正文会参与检索，内嵌 JPG、JPEG 和 PNG 图片会在 OCR 启用时通过 RapidOCR 提取文字。
- 人工复核：本机 Word COM 不可用或旧格式转换失败时记录为未解析；视频只登记路径，不做转写或抽帧。

解析失败不会静默丢失，而是写入材料清单和 `run.log`。
