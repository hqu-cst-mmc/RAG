from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Any
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from .models import RunState
from .rubric import load_rubric
WINDOWS_INVALID_FILENAME_CHARACTERS = re.compile('[<>:"/\\\\|?*\\x00-\\x1f]')

def _display(value: Any) -> str:
    if value is None:
        return 'NA'
    if isinstance(value, bool):
        return '是' if value else '否'
    if isinstance(value, float):
        return f'{value:.4f}'.rstrip('0').rstrip('.')
    if isinstance(value, list):
        return '；'.join((str(item) for item in value))
    return str(value)

def site_workbook_filename(site_id: str) -> str:
    safe_site_id = WINDOWS_INVALID_FILENAME_CHARACTERS.sub('_', site_id).strip(' .')
    return f"{safe_site_id or 'site'}.xlsx"

def _markdown(rows: list[dict[str, Any]], headers: list[str]) -> str:

    def escape(value: Any) -> str:
        return _display(value).replace('|', '\\|').replace('\n', '<br>')
    lines = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(('---' for _ in headers)) + ' |']
    lines.extend(('| ' + ' | '.join((escape(row.get(header, '')) for header in headers)) + ' |' for row in rows))
    return '\n'.join(lines)

def build_assignment_rows(state: RunState) -> list[dict[str, Any]]:
    rubric = load_rubric()
    rows: list[dict[str, Any]] = []
    for indicator_id in [f'C{i}' for i in range(1, 39)]:
        score = state.scores[indicator_id]
        rows.append({'站点编号': state.profile.site_id, '站点名称': state.profile.site_name, '场景类型': state.profile.scenario_type, '指标编号': indicator_id, '指标名称': rubric.indicators[indicator_id].name, '原始分值': score.raw_score, '模糊集值': score.fuzzy_score, '赋值理由': score.reason, '证据摘要': score.evidence_summary, '证据来源': score.sources, '可信度': score.confidence, '是否人工复核': score.needs_review})
    c39 = state.c39
    if c39 is not None:
        rows.append({'站点编号': state.profile.site_id, '站点名称': state.profile.site_name, '场景类型': state.profile.scenario_type, '指标编号': 'C39', '指标名称': rubric.indicators['C39'].name, '原始分值': c39.official_score if c39.official_score is not None else c39.official_grade, '模糊集值': c39.reference_value, '赋值理由': c39.status, '证据摘要': c39.notes, '证据来源': '', '可信度': '高' if c39.usable_as_external_reference else '低', '是否人工复核': not c39.usable_as_external_reference})
    return rows

def build_evidence_rows(state: RunState) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for indicator_id in [f'C{i}' for i in range(1, 39)]:
        evidence = state.evidence[indicator_id]
        rows.append({'站点编号': state.profile.site_id, '指标编号': indicator_id, '证据摘要': evidence.summary, '材料名称': evidence.sources, '材料类型': evidence.evidence_type, '证据强度': evidence.strength, '能否支撑高分': evidence.strength == '强' and (not evidence.needs_review), '备注': evidence.missing_materials})
    return rows

def build_index_rows(state: RunState) -> list[dict[str, Any]]:
    indices = state.indices
    if indices is None:
        return []
    row: dict[str, Any] = {'站点编号': state.profile.site_id}
    row.update(indices.secondary_scores)
    row.update({'PV': indices.pv_normalized, 'MC': indices.mc_normalized, 'SB': indices.sb, '材料完整度': state.profile.completeness})
    return [row]

def build_review_rows(state: RunState) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    hit_rules: dict[str, list[str]] = {}
    for hit in state.rule_hits:
        hit_rules.setdefault(hit.indicator_id, []).append(hit.rule)
    for indicator_id in [f'C{i}' for i in range(1, 39)]:
        score = state.scores[indicator_id]
        evidence = state.evidence[indicator_id]
        if not (score.needs_review or evidence.needs_review or indicator_id in hit_rules):
            continue
        reasons = hit_rules.get(indicator_id, [])
        if evidence.needs_review:
            reasons.append('证据提取阶段建议人工复核')
        rows.append({'站点编号': state.profile.site_id, '指标编号': indicator_id, '当前分值': score.raw_score, '复核原因': reasons or ['评分阶段建议人工复核'], '建议补充材料': score.improvement_materials or evidence.missing_materials, '是否必须复核': indicator_id in hit_rules or score.raw_score is None})
    return rows

def _write_sheet(workbook: Workbook, title: str, rows: list[dict[str, Any]], headers: list[str]) -> None:
    sheet = workbook.create_sheet(title)
    sheet.append(headers)
    for row in rows:
        sheet.append([_display(row.get(header, '')) for header in headers])
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for column in sheet.columns:
        column_letter = column[0].column_letter
        max_length = min(max((len(str(cell.value or '')) for cell in column)), 60)
        sheet.column_dimensions[column_letter].width = max(12, max_length + 2)
        for cell in column:
            cell.alignment = Alignment(vertical='top', wrap_text=True)
    sheet.freeze_panes = 'A2'

def export_run(state: RunState, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    assignment_rows = build_assignment_rows(state)
    evidence_rows = build_evidence_rows(state)
    index_rows = build_index_rows(state)
    review_rows = build_review_rows(state)
    assignment_headers = ['站点编号', '站点名称', '场景类型', '指标编号', '指标名称', '原始分值', '模糊集值', '赋值理由', '证据摘要', '证据来源', '可信度', '是否人工复核']
    evidence_headers = ['站点编号', '指标编号', '证据摘要', '材料名称', '材料类型', '证据强度', '能否支撑高分', '备注']
    index_headers = ['站点编号', *[f'B{i}' for i in range(1, 12)], 'PV', 'MC', 'SB', '材料完整度']
    review_headers = ['站点编号', '指标编号', '当前分值', '复核原因', '建议补充材料', '是否必须复核']
    workbook = Workbook()
    workbook.remove(workbook.active)
    _write_sheet(workbook, '完整赋值表', assignment_rows, assignment_headers)
    _write_sheet(workbook, '证据矩阵', evidence_rows, evidence_headers)
    _write_sheet(workbook, '二级指标和综合指数', index_rows, index_headers)
    _write_sheet(workbook, '人工复核清单', review_rows, review_headers)
    workbook.save(output_dir / site_workbook_filename(state.profile.site_id))
    report = _build_report(state, assignment_rows, evidence_rows, index_rows, review_rows, assignment_headers, evidence_headers, index_headers, review_headers)
    (output_dir / 'report.md').write_text(report, encoding='utf-8')
    (output_dir / 'result.json').write_text(json.dumps(state.model_dump(mode='json'), ensure_ascii=False, indent=2), encoding='utf-8')
    (output_dir / 'run.log').write_text('\n'.join(state.warnings) if state.warnings else 'No warnings.\n', encoding='utf-8')

def _build_report(state: RunState, assignment_rows: list[dict[str, Any]], evidence_rows: list[dict[str, Any]], index_rows: list[dict[str, Any]], review_rows: list[dict[str, Any]], assignment_headers: list[str], evidence_headers: list[str], index_headers: list[str], review_headers: list[str]) -> str:
    c39 = state.c39
    indices = state.indices
    material_rows = [{'材料名称': item.relative_path, '类型': item.material_type, '解析状态': item.status, '说明': item.error or (f'重复于 {item.duplicate_of}' if item.duplicate_of else '')} for item in state.materials]
    lines = [f'# {state.profile.site_name} 基层应急公共服务评价初稿', '', '## 站点基本信息', f'- 站点编号：{state.profile.site_id}', f"- 评分模式：{'模型初评 + 规则约束 + 人工复核清单'}", f'- 场景类型：{state.profile.scenario_type}', f'- 主要风险场景：{_display(state.profile.major_risks)}', f'- 材料完整度：{state.profile.completeness}。{state.profile.completeness_reason}', f'- 官方考核表：{_display(state.profile.has_official_assessment)}', f'- 官方得分、等级或验收结论：{_display(state.profile.has_official_result)}', '', '## 材料清单', _markdown(material_rows, ['材料名称', '类型', '解析状态', '说明']), '', '## C1-C38 证据表', _markdown(evidence_rows, evidence_headers), '', '## C1-C39 完整赋值表', _markdown(assignment_rows, assignment_headers), '', '## C39 标准化建设基础指标', f"- 资料状态：{(c39.status if c39 else '缺失')}", f'- 折算值：{_display(c39.reference_value if c39 else None)}', f"- 注意事项：{(c39.notes if c39 else 'C39未处理。')}", '', '## 二级指标和综合指数', _markdown(index_rows, index_headers), f'- PV 原始均值：{_display(indices.pv_raw if indices else None)}', f'- PV 0-1 折算值：{_display(indices.pv_normalized if indices else None)}', f'- MC 原始均值：{_display(indices.mc_raw if indices else None)}', f'- MC 0-1 折算值：{_display(indices.mc_normalized if indices else None)}', '', *['## 最需要人工复核的指标', _markdown(review_rows[:5], review_headers), ''], '## 表1：C1-C39完整赋值表', _markdown(assignment_rows, assignment_headers), '', '## 表2：证据矩阵', _markdown(evidence_rows, evidence_headers), '', '## 表3：二级指标和综合指数表', _markdown(index_rows, index_headers), '', *['## 表4：人工复核清单', _markdown(review_rows, review_headers), '']]
    return '\n'.join(lines)
