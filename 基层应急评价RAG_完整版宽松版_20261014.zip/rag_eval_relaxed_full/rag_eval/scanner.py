from __future__ import annotations

import hashlib
from pathlib import Path

from pydantic import BaseModel

from .models import MaterialRecord, Rubric

ASPECT_KEYWORDS = {
    "组织机构": ("组织机构", "工作机构", "领导小组", "人员名单", "职责"),
    "运行机制": ("运行机制", "工作机制", "制度", "值班", "会商", "巡查"),
    "指挥平台": ("指挥平台", "通信", "广播", "视频会议", "卫星电话"),
    "队伍": ("队伍", "救援队", "消防站", "花名册"),
    "执法": ("执法", "行政处罚", "检查"),
    "物资": ("物资", "仓库", "储备"),
    "宣传": ("宣传", "宣教", "公众号", "警示栏"),
    "演练": ("演练", "训练", "复盘"),
    "重点人群": ("重点人群", "威胁人员", "脆弱群体"),
    "安置救助": ("安置", "避灾", "救助"),
    "恢复支持": ("恢复", "帮扶", "重建"),
    "反馈复盘": ("反馈", "复盘", "评估"),
}

STRUCTURED_TYPES = {"制度文本", "台账清单", "官方考核表", "演练记录"}
REFERENCE_RULE_DOCUMENT_STEMS = {"基层应急公共服务公共价值生成评价赋值大纲"}


class CompletenessResult(BaseModel):
    level: str
    success_rate: float
    aspects: list[str]
    processed_files: int
    total_processable_files: int
    structured_materials: int
    reason: str


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def is_reference_rule_document(path: Path) -> bool:
    return path.stem in REFERENCE_RULE_DOCUMENT_STEMS


def find_reference_rule_documents(root: Path) -> list[Path]:
    if not root.is_dir():
        return []
    return sorted(path for path in root.rglob("*") if path.is_file() and is_reference_rule_document(path))


def classify_material_type(path: Path) -> str:
    combined = path.as_posix()
    suffix = path.suffix.lower()
    if any(term in combined for term in ("评价表", "评估表", "评分表", "验收表", "考核表")):
        return "官方考核表"
    if any(term in combined for term in ("台账", "清单", "名单", "花名册", "明细表")):
        return "台账清单"
    if any(term in combined for term in ("演练", "训练", "复盘")):
        return "演练记录"
    if any(term in combined for term in ("宣传", "公众号", "警示栏")):
        return "宣传材料"
    if suffix in {".doc", ".docx", ".docm", ".wps", ".pdf"}:
        return "制度文本"
    if suffix in {".jpg", ".jpeg", ".png"}:
        return "照片截图"
    if suffix in {".xlsx", ".xls"}:
        return "台账清单"
    if suffix in {".mp4", ".mov", ".avi"}:
        return "其他"
    return "其他"


def scan_materials(site_dir: Path) -> list[MaterialRecord]:
    root = site_dir.resolve()
    if not root.is_dir():
        raise ValueError(f"Site directory does not exist: {site_dir}")
    materials: list[MaterialRecord] = []
    first_by_hash: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(
            part == "__MACOSX"
            or part.startswith("._")
            or part.startswith(".")
            or part.startswith("~$")
            for part in relative.parts
        ):
            continue
        if is_reference_rule_document(relative):
            continue
        sha256 = _sha256(path)
        record_id = hashlib.sha256(f"{relative.as_posix()}:{sha256}".encode("utf-8")).hexdigest()[:20]
        duplicate_of = first_by_hash.get(sha256)
        record = MaterialRecord(
            id=record_id,
            relative_path=relative.as_posix(),
            name=path.name,
            extension=path.suffix.lower(),
            size=path.stat().st_size,
            sha256=sha256,
            material_type=classify_material_type(relative),
            duplicate_of=duplicate_of,
            status="duplicate" if duplicate_of else "pending",
        )
        materials.append(record)
        first_by_hash.setdefault(sha256, record_id)
    return materials


def detect_aspects(materials: list[MaterialRecord]) -> list[str]:
    combined_paths = "\n".join(item.relative_path for item in materials)
    return [
        aspect
        for aspect, keywords in ASPECT_KEYWORDS.items()
        if any(keyword in combined_paths for keyword in keywords)
    ]


def assess_completeness(materials: list[MaterialRecord], rubric: Rubric) -> CompletenessResult:
    unique = [item for item in materials if item.duplicate_of is None and item.extension not in {".mp4", ".mov", ".avi"}]
    processed = [item for item in unique if item.status == "parsed"]
    success_rate = len(processed) / len(unique) if unique else 0.0
    aspects = detect_aspects(materials)
    structured = sum(item.material_type in STRUCTURED_TYPES for item in processed)
    thresholds = rubric.completeness
    if (
        success_rate >= float(thresholds["high_success_rate"])
        and len(aspects) >= int(thresholds["high_aspects"])
        and structured > 0
    ):
        level = "高"
    elif (
        success_rate >= float(thresholds["medium_success_rate"])
        and len(aspects) >= int(thresholds["medium_aspects"])
    ):
        level = "中"
    else:
        level = "低"
    reason = (
        f"可处理文件成功率 {success_rate:.1%}；覆盖 {len(aspects)} 个方面；"
        f"制度、台账、考核表或演练记录类文件 {structured} 个。"
    )
    return CompletenessResult(
        level=level,
        success_rate=success_rate,
        aspects=aspects,
        processed_files=len(processed),
        total_processable_files=len(unique),
        structured_materials=structured,
        reason=reason,
    )
