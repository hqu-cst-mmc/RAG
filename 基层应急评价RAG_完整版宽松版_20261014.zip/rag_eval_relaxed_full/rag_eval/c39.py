from __future__ import annotations

import re
from dataclasses import dataclass, replace
from pathlib import Path
from xml.etree import ElementTree
from zipfile import ZipFile

from .models import MaterialRecord

WORD_NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
TOWNSHIP_ASSESSMENT_TITLE_PATTERN = re.compile(
    r"(?:乡镇|镇)（街道）标准化应急管理站建设(?:情况)?(?:评价|评估)表"
)
TOTAL_SCORE_PATTERN = re.compile(r"总分\s*[:：]?\s*(\d+(?:\.\d+)?)\s*分")
SCORE_CELL_PATTERN = re.compile(r"\s*(\d+(?:\.\d+)?)\s*分?\s*")
GRADE_LABELS = ("优秀", "良好", "合格", "基本合格", "不合格")
CHECKED_MARKS = ("☑", "☒", "■", "√", "✓")
STATION_SCOPE_MARKER_GROUPS = (
    ("工作机构", "工作场所", "专职人员"),
    ("指挥", "通信", "广播"),
    ("运行机制", "风险隐患", "网格"),
    ("执法",),
    ("救援队伍", "消防站"),
    ("预案", "值班值守", "信息报告"),
    ("物资", "仓库", "避灾"),
    ("宣传", "宣教"),
)


@dataclass(frozen=True)
class OfficialScoreExtraction:
    official_score: float
    max_score: float
    source: str
    method: str


@dataclass(frozen=True)
class OfficialGradeExtraction:
    official_grade: str
    source: str
    method: str


@dataclass(frozen=True)
class OfficialScoreCandidate:
    candidate_id: str
    official_score: float
    max_score: float
    source: str
    table_index: int
    title: str
    preview: list[str]
    method: str
    station_scope_score: int
    title_score: int

    def as_extraction(self) -> OfficialScoreExtraction:
        return OfficialScoreExtraction(
            official_score=self.official_score,
            max_score=self.max_score,
            source=self.source,
            method=self.method,
        )


def _cell_text(cell: ElementTree.Element) -> str:
    return "".join(node.text or "" for node in cell.findall(".//w:t", WORD_NS)).strip()


def _table_rows(table: ElementTree.Element) -> list[list[str]]:
    return [
        [_cell_text(cell) for cell in row.findall("./w:tc", WORD_NS)]
        for row in table.findall("./w:tr", WORD_NS)
    ]


def _parse_score_cell(text: str) -> float | None:
    match = SCORE_CELL_PATTERN.fullmatch(text)
    return float(match.group(1)) if match else None


def _checked_grade(text: str) -> str | None:
    compact = "".join(text.split())
    for grade in GRADE_LABELS:
        if any(f"{mark}{grade}" in compact for mark in CHECKED_MARKS):
            return grade
    return None


def _station_scope_score(text: str) -> int:
    return sum(any(marker in text for marker in group) for group in STATION_SCOPE_MARKER_GROUPS)


def _table_title(rows: list[list[str]], table_index: int) -> str:
    for row in rows[:3]:
        text = " | ".join(cell for cell in row if cell)
        if text:
            return text[:240]
    return f"表格 {table_index}"


def _table_preview(rows: list[list[str]]) -> list[str]:
    return [
        " | ".join(cell for cell in row if cell)[:500]
        for row in rows[:6]
        if any(cell for cell in row)
    ]


def _score_table_candidates(
    root: ElementTree.Element,
    relative_path: str,
) -> list[OfficialScoreCandidate]:
    candidates: list[OfficialScoreCandidate] = []
    for table_index, table in enumerate(root.findall(".//w:tbl", WORD_NS), start=1):
        rows = _table_rows(table)
        text = "\n".join(cell for row in rows for cell in row)
        header_index = next(
            (
                index
                for index, row in enumerate(rows)
                if "占比" in row and "小计" in row
            ),
            None,
        )
        if header_index is None:
            continue
        official_score = 0.0
        max_score = 0.0
        scored_cells = 0
        for row in rows[header_index + 1 :]:
            if len(row) < 2:
                continue
            row_max_score = _parse_score_cell(row[-2])
            if row_max_score is None:
                continue
            max_score += row_max_score
            row_score = _parse_score_cell(row[-1])
            if row_score is not None:
                official_score += row_score
                scored_cells += 1
        if max_score > 0 and scored_cells > 0 and official_score <= max_score:
            candidates.append(
                OfficialScoreCandidate(
                    candidate_id=f"{relative_path}#table-{table_index}",
                    official_score=official_score,
                    max_score=max_score,
                    source=relative_path,
                    table_index=table_index,
                    title=_table_title(rows, table_index),
                    preview=_table_preview(rows),
                    method="subtotal_sum",
                    station_scope_score=_station_scope_score(text),
                    title_score=1 if TOWNSHIP_ASSESSMENT_TITLE_PATTERN.search(text) else 0,
                )
            )
    return candidates


def _extract_docx_score_candidates(path: Path, relative_path: str) -> list[OfficialScoreCandidate]:
    with ZipFile(path) as archive:
        root = ElementTree.fromstring(archive.read("word/document.xml"))
    candidates = _score_table_candidates(root, relative_path)
    if not candidates:
        return []
    document_text = "\n".join(
        "".join(node.text or "" for node in paragraph.findall(".//w:t", WORD_NS))
        for paragraph in root.findall(".//w:p", WORD_NS)
    )
    explicit_total = TOTAL_SCORE_PATTERN.search(document_text)
    explicit_score = float(explicit_total.group(1)) if explicit_total else None
    if len(candidates) == 1 and explicit_score is not None and explicit_score <= candidates[0].max_score:
        candidates[0] = replace(candidates[0], official_score=explicit_score, method="explicit_total")
    return candidates


def _extract_docx_grade(path: Path, relative_path: str) -> OfficialGradeExtraction | None:
    with ZipFile(path) as archive:
        root = ElementTree.fromstring(archive.read("word/document.xml"))
    grades: set[str] = set()
    for table in root.findall(".//w:tbl", WORD_NS):
        rows = _table_rows(table)
        text = "\n".join(cell for row in rows for cell in row)
        if _station_scope_score(text) < 2:
            continue
        for row in rows:
            row_text = " ".join(row)
            if "综合评价" not in row_text:
                continue
            grade = _checked_grade(row_text)
            if grade is not None:
                grades.add(grade)
    if len(grades) != 1:
        return None
    return OfficialGradeExtraction(
        official_grade=grades.pop(),
        source=relative_path,
        method="explicit_comprehensive_grade",
    )


def collect_official_score_candidates(site_dir: Path, materials: list[MaterialRecord]) -> list[OfficialScoreCandidate]:
    candidates: list[OfficialScoreCandidate] = []
    root = site_dir.resolve()
    for material in materials:
        if (
            material.duplicate_of is not None
            or material.material_type != "官方考核表"
            or material.extension not in {".docx", ".docm"}
        ):
            continue
        try:
            candidates.extend(_extract_docx_score_candidates(root / material.relative_path, material.relative_path))
        except (KeyError, OSError, ValueError):
            continue
    return candidates


def extract_official_score(site_dir: Path, materials: list[MaterialRecord]) -> OfficialScoreExtraction | None:
    candidates = collect_official_score_candidates(site_dir, materials)
    return candidates[0].as_extraction() if len(candidates) == 1 else None


def extract_official_grade(site_dir: Path, materials: list[MaterialRecord]) -> OfficialGradeExtraction | None:
    candidates: list[OfficialGradeExtraction] = []
    root = site_dir.resolve()
    for material in materials:
        if material.material_type != "官方考核表" or material.extension not in {".docx", ".docm"}:
            continue
        try:
            candidate = _extract_docx_grade(root / material.relative_path, material.relative_path)
        except (KeyError, OSError, ValueError):
            continue
        if candidate is not None:
            candidates.append(candidate)
    unique_grades = {candidate.official_grade for candidate in candidates}
    return candidates[0] if len(unique_grades) == 1 else None
