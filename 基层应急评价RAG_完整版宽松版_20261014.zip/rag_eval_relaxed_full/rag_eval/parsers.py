from __future__ import annotations

import hashlib
import json
import tempfile
from collections.abc import Iterable
from pathlib import Path
from typing import Callable, Protocol
from xml.etree import ElementTree
from zipfile import ZipFile

from .models import Chunk, MaterialRecord
from .ocr import OCRResult, RapidOCREngine

WORD_NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}
VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi"}


class OCREngine(Protocol):
    def extract(self, path: Path) -> OCRResult: ...


class MaterialParser:
    def __init__(
        self,
        *,
        ocr_engine: OCREngine | None = None,
        ocr_cache_dir: Path | None = None,
        enable_ocr: bool = True,
    ) -> None:
        self.ocr_engine = ocr_engine
        self.ocr_cache_dir = ocr_cache_dir
        self.enable_ocr = enable_ocr

    def parse(self, root: Path, material: MaterialRecord) -> list[Chunk]:
        path = root / material.relative_path
        extension = material.extension
        if extension in VIDEO_EXTENSIONS:
            material.status = "registered"
            material.parser = "video-metadata"
            return []
        try:
            if extension in {".docx", ".docm"}:
                rows = self._parse_docx(path)
                parser = "docx"
            elif extension == ".xlsx":
                rows = self._parse_xlsx(path)
                parser = "openpyxl"
            elif extension == ".xls":
                rows = self._parse_xls(path)
                parser = "xlrd"
            elif extension == ".pdf":
                rows = self._parse_pdf(path)
                parser = "pypdf"
            elif extension in IMAGE_EXTENSIONS:
                rows = self._parse_image(path, material.sha256)
                parser = "rapidocr"
            elif extension in {".doc", ".wps"}:
                rows = self._parse_legacy_word(path)
                parser = "office-com"
            elif extension in {".txt", ".md", ".csv", ".tsv"}:
                rows = [("文本", path.read_text(encoding="utf-8", errors="replace"), {})]
                parser = "text"
            else:
                material.status = "unsupported"
                material.error = f"Unsupported extension: {extension or '<none>'}"
                return []
            material.status = "parsed"
            material.parser = parser
            return self._chunks(material, rows)
        except Exception as exc:  # Keep one damaged file from aborting a full-site evaluation.
            material.status = "unparsed"
            material.error = f"{type(exc).__name__}: {exc}"
            return []

    def _chunks(
        self,
        material: MaterialRecord,
        rows: Iterable[tuple[str, str, dict[str, str | int | float | bool | None]]],
    ) -> list[Chunk]:
        chunks: list[Chunk] = []
        for index, (locator, text, metadata) in enumerate(rows, start=1):
            normalized = " ".join(str(text).split())
            if not normalized:
                continue
            for part_number, start in enumerate(range(0, len(normalized), 1800), start=1):
                part = normalized[start : start + 1800]
                part_locator = locator if len(normalized) <= 1800 else f"{locator} 片段 {part_number}"
                chunks.append(
                    Chunk(
                        id=f"{material.id}:{index}:{part_number}",
                        material_id=material.id,
                        relative_path=material.relative_path,
                        text=part,
                        locator=part_locator,
                        material_type=material.material_type,
                        metadata=metadata,
                    )
                )
        return chunks

    def _parse_docx(
        self,
        path: Path,
        *,
        include_embedded_images: bool = False,
    ) -> list[tuple[str, str, dict]]:
        with ZipFile(path) as archive:
            xml = archive.read("word/document.xml")
        root = ElementTree.fromstring(xml)
        rows: list[tuple[str, str, dict]] = []
        for index, paragraph in enumerate(root.findall(".//w:p", WORD_NS), start=1):
            text = "".join(node.text or "" for node in paragraph.findall(".//w:t", WORD_NS))
            if text.strip():
                rows.append((f"段落 {index}", text, {"paragraph": index}))
        if include_embedded_images and self.enable_ocr:
            rows.extend(self._parse_docx_embedded_images(path))
        return rows

    def _parse_xlsx(self, path: Path) -> list[tuple[str, str, dict]]:
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise RuntimeError("openpyxl is required to parse .xlsx files") from exc
        workbook = load_workbook(path, read_only=True, data_only=True)
        rows: list[tuple[str, str, dict]] = []
        try:
            for sheet in workbook.worksheets:
                for row_number, values in enumerate(sheet.iter_rows(values_only=True), start=1):
                    cells = [str(value) for value in values if value is not None and str(value).strip()]
                    if cells:
                        rows.append(
                            (
                                f"工作表 {sheet.title} 行 {row_number}",
                                " | ".join(cells),
                                {"sheet": sheet.title, "row": row_number},
                            )
                        )
        finally:
            workbook.close()
        return rows

    def _parse_xls(self, path: Path) -> list[tuple[str, str, dict]]:
        try:
            import xlrd
        except ImportError as exc:
            raise RuntimeError("xlrd is required to parse .xls files") from exc
        workbook = xlrd.open_workbook(path)
        rows: list[tuple[str, str, dict]] = []
        for sheet in workbook.sheets():
            for row_index in range(sheet.nrows):
                cells = [str(value) for value in sheet.row_values(row_index) if str(value).strip()]
                if cells:
                    rows.append(
                        (
                            f"工作表 {sheet.name} 行 {row_index + 1}",
                            " | ".join(cells),
                            {"sheet": sheet.name, "row": row_index + 1},
                        )
                    )
        return rows

    def _parse_pdf(self, path: Path) -> list[tuple[str, str, dict]]:
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise RuntimeError("pypdf is required to parse .pdf files") from exc
        return [
            (f"页码 {page_number}", page.extract_text() or "", {"page": page_number})
            for page_number, page in enumerate(PdfReader(str(path)).pages, start=1)
        ]

    def _parse_image(self, path: Path, sha256: str) -> list[tuple[str, str, dict]]:
        result = self._extract_image_text(path, sha256)
        return [(
            f"图片 {path.name}",
            result.text,
            {"image": path.name, "ocr_confidence": result.confidence},
        )]

    def _extract_image_text(self, path: Path, sha256: str) -> OCRResult:
        if not self.enable_ocr:
            raise RuntimeError("OCR is disabled")
        cache_dir = self.ocr_cache_dir
        cache_path = cache_dir / f"{sha256}.json" if cache_dir else None
        if cache_path and cache_path.exists():
            result = OCRResult.model_validate_json(cache_path.read_text(encoding="utf-8"))
        else:
            if self.ocr_engine is None:
                self.ocr_engine = RapidOCREngine()
            result = self.ocr_engine.extract(path)
            if cache_path:
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                cache_path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        return result

    def _parse_docx_embedded_images(self, path: Path) -> list[tuple[str, str, dict]]:
        rows: list[tuple[str, str, dict]] = []
        with ZipFile(path) as archive, tempfile.TemporaryDirectory(prefix="rag-eval-docx-media-") as temp_dir:
            for archive_name in sorted(archive.namelist()):
                image_name = Path(archive_name).name
                if not archive_name.startswith("word/media/") or Path(image_name).suffix.lower() not in IMAGE_EXTENSIONS:
                    continue
                image_bytes = archive.read(archive_name)
                extracted = Path(temp_dir) / image_name
                extracted.write_bytes(image_bytes)
                result = self._extract_image_text(extracted, hashlib.sha256(image_bytes).hexdigest())
                rows.append(
                    (
                        f"内嵌图片 {image_name}",
                        result.text,
                        {
                            "image": image_name,
                            "embedded_image": True,
                            "ocr_confidence": result.confidence,
                        },
                    )
                )
        return rows

    def _parse_legacy_word(self, path: Path) -> list[tuple[str, str, dict]]:
        with tempfile.TemporaryDirectory(prefix="rag-eval-word-") as temp_dir:
            converted = Path(temp_dir) / f"{path.stem}.docx"
            self._convert_legacy_word_to_docx(path, converted)
            if not converted.exists():
                raise RuntimeError("Office conversion did not produce a .docx file")
            return self._parse_docx(converted, include_embedded_images=True)

    def _convert_legacy_word_to_docx(self, path: Path, converted: Path) -> None:
        try:
            import win32com.client
        except ImportError as exc:
            raise RuntimeError("pywin32 is required for legacy Word conversion") from exc
        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0
        document = None
        try:
            document = word.Documents.Open(str(path.resolve()), ReadOnly=True)
            document.SaveAs2(str(converted), FileFormat=16)
        finally:
            if document is not None:
                document.Close(False)
            word.Quit()


def parse_materials(
    site_dir: Path,
    materials: list[MaterialRecord],
    parser: MaterialParser,
    progress: Callable[[int, int, MaterialRecord], None] | None = None,
) -> tuple[list[Chunk], list[MaterialRecord]]:
    root = site_dir.resolve()
    parsed_materials = [item.model_copy(deep=True) for item in materials]
    chunks: list[Chunk] = []
    unique_materials = [item for item in parsed_materials if item.duplicate_of is None]
    total = len(unique_materials)
    current = 0
    for material in parsed_materials:
        if material.duplicate_of is not None:
            continue
        chunks.extend(parser.parse(root, material))
        current += 1
        if progress is not None:
            progress(current, total, material)
    return chunks, parsed_materials
