"""RAG-assisted grassroots emergency public service evaluation."""

__version__ = "0.1.0"

