from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from statistics import fmean

from .models import C39Result, EvidenceItem, IndexResult, Rubric, RuleHit, ScoreItem
from .rubric import load_rubric

FUZZY_VALUES = {0: 0.0, 1: 0.33, 2: 0.67, 3: 1.0}
GRADE_VALUES = {"优秀": 0.90, "良好": 0.75, "合格": 0.60, "基本合格": 0.40, "不合格": 0.20}


def _has_any(text: str, phrases: tuple[str, ...]) -> bool:
    return any(phrase in text for phrase in phrases)


def _cap(
    scores: dict[str, ScoreItem],
    hits: list[RuleHit],
    indicator_id: str,
    limit: int,
    rule: str,
) -> None:
    item = scores.get(indicator_id)
    if item is None or item.raw_score is None or item.raw_score <= limit:
        return
    previous = item.raw_score
    item.raw_score = limit
    item.fuzzy_score = FUZZY_VALUES[limit]
    item.needs_review = True
    hits.append(RuleHit(indicator_id=indicator_id, previous_score=previous, capped_score=limit, rule=rule))


def _append_adjustment_reason(item: ScoreItem, message: str) -> None:
    if message not in item.reason:
        item.reason = f"{item.reason}；{message}" if item.reason else message


def normalize_scores(
    score_items: Mapping[str, ScoreItem],
    evidence_items: Mapping[str, EvidenceItem],
) -> dict[str, ScoreItem]:
    scores = {key: deepcopy(value) for key, value in score_items.items()}
    for indicator_id, item in scores.items():
        if item.raw_score is None:
            item.raw_score = 0
            item.needs_review = True
            _append_adjustment_reason(item, "规则校正：模型未给出分值，按缺乏相关证据保守记0分")
        evidence = evidence_items.get(indicator_id)
        if item.raw_score == 0 and evidence is not None and evidence.found != "否" and evidence.strength != "无":
            item.raw_score = 1
            item.needs_review = True
            if evidence.found == "是":
                _append_adjustment_reason(item, "规则校正：已提取到相关做法证据，按零散表现至少记1分")
            else:
                _append_adjustment_reason(
                    item,
                    "宽松版规则校正：材料存在弱关联或间接关联，按零散表现酌情记1分并建议人工复核",
                )
        item.fuzzy_score = FUZZY_VALUES[item.raw_score]
    return scores


def apply_score_caps(
    score_items: Mapping[str, ScoreItem],
    evidence_items: Mapping[str, EvidenceItem],
    rubric: Rubric | None = None,
) -> tuple[dict[str, ScoreItem], list[RuleHit]]:
    scores = normalize_scores(score_items, evidence_items)
    hits: list[RuleHit] = []

    summaries = {
        key: f"{item.summary} {' '.join(item.sources)}"
        for key, item in evidence_items.items()
    }
    active_rubric = rubric or load_rubric()
    for definition in active_rubric.score_caps:
        evidence = evidence_items.get(definition.indicator_id)
        if definition.evidence_type and (evidence is None or evidence.evidence_type != definition.evidence_type):
            continue
        summary = summaries.get(definition.indicator_id, "")
        if not _has_any(summary, tuple(definition.required_any)):
            _cap(scores, hits, definition.indicator_id, definition.max_score, definition.rule)

    return scores, hits


def _average(values: list[float | None]) -> float | None:
    valid = [value for value in values if value is not None]
    return fmean(valid) if valid else None


def calculate_indices(scores: Mapping[str, ScoreItem], rubric: Rubric, sb: float | None = None) -> IndexResult:
    secondary_scores: dict[str, float | None] = {}
    for secondary_id, indicator_ids in rubric.secondary_groups.items():
        secondary_scores[secondary_id] = _average(
            [
                scores[indicator_id].raw_score
                if indicator_id in scores and scores[indicator_id].raw_score is not None
                else 0
                for indicator_id in indicator_ids
            ]
        )
    pv_raw = _average([secondary_scores[f"B{i}"] for i in range(1, 6)])
    mc_raw = _average([secondary_scores[f"B{i}"] for i in range(6, 12)])
    return IndexResult(
        secondary_scores=secondary_scores,
        pv_raw=pv_raw,
        pv_normalized=None if pv_raw is None else pv_raw / 3,
        mc_raw=mc_raw,
        mc_normalized=None if mc_raw is None else mc_raw / 3,
        sb=sb,
    )


def classify_c39(
    *,
    official_score: float | None = None,
    max_score: float | None = None,
    official_grade: str | None = None,
    materials_detailed: bool = False,
) -> C39Result:
    if official_score is not None:
        if not max_score or max_score <= 0:
            return C39Result(
                status="官方分数不完整",
                official_score=official_score,
                max_score=max_score,
                reference_kind="SB",
                usable_as_external_reference=False,
                notes="已提取官方实际得分，但缺少有效满分；无法计算SB，需要人工复核官方考核表。",
            )
        return C39Result(
            status="有完整官方分数",
            official_score=official_score,
            max_score=max_score,
            reference_kind="SB",
            reference_value=official_score / max_score,
            usable_as_external_reference=True,
            notes="官方得分仅作为外部参照变量，不直接推高C1-C38。",
        )
    if official_grade is not None:
        if official_grade not in GRADE_VALUES:
            raise ValueError(f"Unsupported official grade: {official_grade}")
        return C39Result(
            status="只有等级",
            official_grade=official_grade,
            reference_kind="SBg",
            reference_value=GRADE_VALUES[official_grade],
            usable_as_external_reference=True,
            notes="等级折算值不是精确官方分数。",
        )
    if materials_detailed:
        return C39Result(
            status="没有验收表但材料翔实",
            reference_kind="SBe",
            usable_as_external_reference=False,
            notes="材料证据型参照值SBe待人工确定；这不是官方得分。",
        )
    return C39Result(
        status="没有验收表且材料不足",
        usable_as_external_reference=False,
        notes="C39记为缺失。",
    )
