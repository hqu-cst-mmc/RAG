from __future__ import annotations

import hashlib
import math
import re
from collections import Counter, defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from .models import Chunk

TOKEN_PATTERN = re.compile(r"[A-Za-z0-9_]+|[\u4e00-\u9fff]")


@dataclass(frozen=True)
class RetrievalResult:
    chunk: Chunk
    score: float


class DenseBackend(Protocol):
    def index(self, chunks: Sequence[Chunk]) -> None: ...

    def search(self, query: str, limit: int) -> list[str]: ...

    def close(self) -> None: ...


def tokenize(text: str) -> list[str]:
    base = TOKEN_PATTERN.findall(text.lower())
    chinese = [token for token in base if len(token) == 1 and "\u4e00" <= token <= "\u9fff"]
    bigrams = [f"{left}{right}" for left, right in zip(chinese, chinese[1:])]
    return base + bigrams


def reciprocal_rank_fusion(
    rankings: Iterable[Sequence[str]],
    *,
    rank_constant: int = 60,
) -> list[tuple[str, float]]:
    scores: defaultdict[str, float] = defaultdict(float)
    for ranking in rankings:
        for rank, item_id in enumerate(ranking, start=1):
            scores[item_id] += 1 / (rank_constant + rank)
    return sorted(scores.items(), key=lambda item: (-item[1], item[0]))


class FastEmbedQdrantBackend:
    """Optional persistent vector backend backed by FastEmbed and Qdrant local mode."""

    def __init__(
        self,
        storage_path: Path,
        *,
        collection_name: str = "rag_eval_chunks",
        model_name: str = "BAAI/bge-small-zh-v1.5",
    ) -> None:
        try:
            from fastembed import TextEmbedding
            from qdrant_client import QdrantClient
        except ImportError as exc:
            raise RuntimeError(
                "Vector retrieval requires fastembed and qdrant-client. "
                "Install the `full` dependency group."
            ) from exc
        self._models = __import__("qdrant_client").models
        self.client = QdrantClient(path=str(storage_path))
        self.embedder = TextEmbedding(model_name=model_name)
        self.collection_name = collection_name

    def index(self, chunks: Sequence[Chunk]) -> None:
        if not chunks:
            return
        vectors = list(self.embedder.embed([chunk.text for chunk in chunks]))
        size = len(vectors[0])
        if not self.client.collection_exists(self.collection_name):
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=self._models.VectorParams(size=size, distance=self._models.Distance.COSINE),
            )
        points = [
            self._models.PointStruct(
                id=int(hashlib.sha256(chunk.id.encode("utf-8")).hexdigest()[:15], 16),
                vector=vector.tolist(),
                payload={"chunk_id": chunk.id},
            )
            for chunk, vector in zip(chunks, vectors)
        ]
        self.client.upsert(collection_name=self.collection_name, points=points)

    def search(self, query: str, limit: int) -> list[str]:
        query_vector = list(self.embedder.query_embed(query))[0]
        response = self.client.query_points(
            collection_name=self.collection_name,
            query=query_vector.tolist(),
            limit=limit,
        )
        return [
            str(hit.payload["chunk_id"])
            for hit in response.points
            if hit.payload and "chunk_id" in hit.payload
        ]

    def close(self) -> None:
        self.client.close()


class HybridRetriever:
    def __init__(
        self,
        chunks: Sequence[Chunk],
        *,
        enable_vector: bool = True,
        storage_path: Path | None = None,
        dense_backend: DenseBackend | None = None,
    ) -> None:
        self.chunks = list(chunks)
        self.by_id = {chunk.id: chunk for chunk in self.chunks}
        self.document_tokens = {chunk.id: Counter(tokenize(f"{chunk.relative_path} {chunk.text}")) for chunk in chunks}
        self._bm25 = None
        try:
            from rank_bm25 import BM25Okapi
        except ImportError:
            pass
        else:
            if self.chunks:
                self._bm25 = BM25Okapi([list(self.document_tokens[chunk.id].elements()) for chunk in self.chunks])
        self.document_frequency: Counter[str] = Counter()
        for tokens in self.document_tokens.values():
            self.document_frequency.update(tokens.keys())
        self.dense_backend = dense_backend
        if self.dense_backend is None and enable_vector and storage_path is not None:
            self.dense_backend = FastEmbedQdrantBackend(storage_path)
        if self.dense_backend is not None:
            self.dense_backend.index(self.chunks)

    def _keyword_ranking(self, query: str) -> list[tuple[str, float]]:
        query_tokens = Counter(tokenize(query))
        bm25_scores = (
            self._bm25.get_scores(list(query_tokens.elements()))
            if self._bm25 is not None and query_tokens
            else [0.0] * len(self.chunks)
        )
        total = max(len(self.chunks), 1)
        scored: list[tuple[str, float]] = []
        for index, (chunk_id, document_tokens) in enumerate(self.document_tokens.items()):
            score = float(bm25_scores[index])
            for token, query_count in query_tokens.items():
                if token not in document_tokens:
                    continue
                idf = math.log((total + 1) / (self.document_frequency[token] + 1)) + 1
                score += min(query_count, document_tokens[token]) * idf
            scored.append((chunk_id, score))
        return sorted(scored, key=lambda item: (-item[1], item[0]))

    def retrieve(self, query: str, *, limit: int = 12) -> list[RetrievalResult]:
        keyword = self._keyword_ranking(query)
        rankings: list[list[str]] = [[chunk_id for chunk_id, _score in keyword]]
        if self.dense_backend is not None:
            rankings.append(self.dense_backend.search(query, max(limit * 2, 20)))
        fused = reciprocal_rank_fusion(rankings)
        keyword_scores = dict(keyword)
        return [
            RetrievalResult(chunk=self.by_id[chunk_id], score=keyword_scores.get(chunk_id, 0.0) + fused_score)
            for chunk_id, fused_score in fused[:limit]
            if chunk_id in self.by_id
        ]

    def close(self) -> None:
        if self.dense_backend is not None:
            self.dense_backend.close()
