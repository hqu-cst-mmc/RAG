from __future__ import annotations

import json
from functools import lru_cache
from importlib.resources import files

from .models import Rubric


@lru_cache(maxsize=1)
def load_rubric() -> Rubric:
    rubric_path = files("rag_eval").joinpath("rubric.json")
    return Rubric.model_validate(json.loads(rubric_path.read_text(encoding="utf-8")))

