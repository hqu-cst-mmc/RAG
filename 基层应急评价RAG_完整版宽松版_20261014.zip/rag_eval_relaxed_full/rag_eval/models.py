from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

FoundState = Literal["是", "否", "不确定"]
EvidenceStrength = Literal["强", "中", "弱", "无"]
Confidence = Literal["高", "中", "低"]
ScenarioType = Literal["城社", "园区", "沿海", "山村", "复合", "其他", "不确定"]


class IndicatorDefinition(BaseModel):
    id: str
    name: str
    secondary: str | None = None


class ScoreCapDefinition(BaseModel):
    indicator_id: str
    max_score: int = Field(ge=0, le=3)
    required_any: list[str]
    rule: str
    evidence_type: str | None = None


class Rubric(BaseModel):
    version: str
    indicators: dict[str, IndicatorDefinition]
    secondary_groups: dict[str, list[str]]
    secondary_names: dict[str, str]
    scenarios: list[str]
    completeness: dict[str, float | int]
    aspects: list[str]
    score_caps: list[ScoreCapDefinition]


class MaterialRecord(BaseModel):
    id: str
    relative_path: str
    name: str
    extension: str
    size: int
    sha256: str
    material_type: str
    status: str = "pending"
    duplicate_of: str | None = None
    parser: str | None = None
    error: str | None = None
    metadata: dict[str, str | int | float | bool | None] = Field(default_factory=dict)


class Chunk(BaseModel):
    id: str
    material_id: str
    relative_path: str
    text: str
    locator: str
    material_type: str
    metadata: dict[str, str | int | float | bool | None] = Field(default_factory=dict)


class EvidenceItem(BaseModel):
    indicator_id: str
    indicator_name: str
    found: FoundState
    summary: str
    sources: list[str]
    evidence_type: str
    strength: EvidenceStrength
    needs_review: bool
    missing_materials: str


class ScoreItem(BaseModel):
    indicator_id: str
    indicator_name: str
    raw_score: int | None = Field(default=None, ge=0, le=3)
    fuzzy_score: float | None = None
    reason: str
    evidence_summary: str
    sources: list[str]
    strength: EvidenceStrength
    confidence: Confidence
    needs_review: bool
    improvement_materials: str


class RuleHit(BaseModel):
    indicator_id: str
    previous_score: int
    capped_score: int
    rule: str


class C39Result(BaseModel):
    status: str
    official_score: float | None = None
    official_grade: str | None = None
    max_score: float | None = None
    reference_kind: str | None = None
    reference_value: float | None = None
    usable_as_external_reference: bool
    notes: str


class IndexResult(BaseModel):
    secondary_scores: dict[str, float | None]
    pv_raw: float | None
    pv_normalized: float | None
    mc_raw: float | None
    mc_normalized: float | None
    sb: float | None = None


class SiteProfile(BaseModel):
    site_id: str
    site_name: str
    scenario_type: ScenarioType = "不确定"
    major_risks: list[str] = Field(default_factory=list)
    completeness: Literal["高", "中", "低"] = "低"
    completeness_reason: str = ""
    aspects: list[str] = Field(default_factory=list)
    has_official_assessment: bool = False
    has_official_result: bool = False


class RunState(BaseModel):
    run_id: str
    model_name: str = "unknown"
    site_dir: str
    output_dir: str
    profile: SiteProfile
    materials: list[MaterialRecord] = Field(default_factory=list)
    chunks: list[Chunk] = Field(default_factory=list)
    evidence: dict[str, EvidenceItem] = Field(default_factory=dict)
    scores: dict[str, ScoreItem] = Field(default_factory=dict)
    rule_hits: list[RuleHit] = Field(default_factory=list)
    c39: C39Result | None = None
    indices: IndexResult | None = None
    warnings: list[str] = Field(default_factory=list)
    completed_nodes: list[str] = Field(default_factory=list)
