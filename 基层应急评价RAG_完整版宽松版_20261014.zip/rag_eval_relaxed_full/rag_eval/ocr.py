from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field


class OCRResult(BaseModel):
    text: str
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)


class RapidOCREngine:
    """Lazy wrapper so scanning still works when the optional OCR package is absent."""

    def __init__(self) -> None:
        self._engine = None

    def _load(self):
        if self._engine is None:
            try:
                from rapidocr_onnxruntime import RapidOCR
            except ImportError as exc:
                raise RuntimeError(
                    "RapidOCR is not installed. Run `python -m rag_eval init-models` "
                    "or install the `full` dependency group."
                ) from exc
            self._engine = RapidOCR()
        return self._engine

    def extract(self, path: Path) -> OCRResult:
        result, _elapsed = self._load()(str(path))
        if not result:
            return OCRResult(text="", confidence=0.0)
        lines: list[str] = []
        confidences: list[float] = []
        for row in result:
            if len(row) >= 3:
                lines.append(str(row[1]))
                confidences.append(float(row[2]))
        confidence = sum(confidences) / len(confidences) if confidences else 0.0
        return OCRResult(text="\n".join(lines), confidence=confidence)

