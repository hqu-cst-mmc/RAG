from __future__ import annotations

import json
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

from pydantic import BaseModel, Field


class BatchSite(BaseModel):
    region_name: str
    site_id: str
    site_name: str
    site_dir: Path


class BatchItemResult(BaseModel):
    region_name: str
    site_id: str
    site_name: str
    site_dir: str
    output_dir: str
    status: str
    error: str | None = None


class BatchResult(BaseModel):
    run_id: str
    data_dir: str
    output_dir: str
    total_sites: int
    succeeded: int
    failed: int
    items: list[BatchItemResult] = Field(default_factory=list)


def discover_batch_sites(data_dir: Path, *, flat_sites: bool = False) -> list[BatchSite]:
    root = data_dir.resolve()
    if not root.is_dir():
        raise ValueError(f"Batch data directory does not exist: {data_dir}")
    if flat_sites:
        sites = [
            BatchSite(
                region_name=root.name,
                site_id=site_dir.name,
                site_name=site_dir.name,
                site_dir=site_dir,
            )
            for site_dir in root.iterdir()
            if site_dir.is_dir()
        ]
        return sorted(sites, key=lambda site: (site.region_name, site.site_id))
    sites = [
        BatchSite(
            region_name=region_dir.name,
            site_id=site_dir.name,
            site_name=site_dir.name,
            site_dir=site_dir,
        )
        for region_dir in root.iterdir()
        if region_dir.is_dir()
        for site_dir in region_dir.iterdir()
        if site_dir.is_dir()
    ]
    return sorted(sites, key=lambda site: (site.region_name, site.site_id))


def _build_markdown(result: BatchResult) -> str:
    lines = [
        "# 批量评价结果",
        "",
        f"- 批次编号：{result.run_id}",
        f"- 站点总数：{result.total_sites}",
        f"- 成功：{result.succeeded}",
        f"- 失败：{result.failed}",
        "",
        "| 县区市 | 站点编号 | 站点名称 | 状态 | 输出目录 | 错误 |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    lines.extend(
        "| "
        + " | ".join(
            [
                item.region_name,
                item.site_id,
                item.site_name,
                item.status,
                item.output_dir,
                item.error or "",
            ]
        )
        + " |"
        for item in result.items
    )
    return "\n".join(lines) + "\n"


def evaluate_batch(
    *,
    data_dir: Path,
    output_dir: Path,
    evaluator: Callable[[Path, str, str, Path], None],
    progress: Callable[[str], None] | None = None,
    run_id: str | None = None,
    flat_sites: bool = False,
) -> BatchResult:
    actual_run_id = run_id or datetime.now().strftime("%Y%m%d-%H%M%S")
    root_output = output_dir.resolve()
    root_output.mkdir(parents=True, exist_ok=True)
    sites = discover_batch_sites(data_dir, flat_sites=flat_sites)
    items: list[BatchItemResult] = []
    for index, site in enumerate(sites, start=1):
        site_output_dir = root_output / site.region_name / site.site_id
        if progress is not None:
            progress(f"[批处理 {index}/{len(sites)}] 开始评价：{site.region_name}/{site.site_id}")
        try:
            evaluator(site.site_dir, site.site_id, site.site_name, site_output_dir)
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            items.append(
                BatchItemResult(
                    region_name=site.region_name,
                    site_id=site.site_id,
                    site_name=site.site_name,
                    site_dir=str(site.site_dir),
                    output_dir=str(site_output_dir),
                    status="failed",
                    error=error,
                )
            )
            if progress is not None:
                progress(f"[批处理 {index}/{len(sites)}] 评价失败：{site.site_id}：{error}")
            continue
        items.append(
            BatchItemResult(
                region_name=site.region_name,
                site_id=site.site_id,
                site_name=site.site_name,
                site_dir=str(site.site_dir),
                output_dir=str(site_output_dir),
                status="succeeded",
            )
        )
        if progress is not None:
            progress(f"[批处理 {index}/{len(sites)}] 评价完成：{site.site_id}")
    result = BatchResult(
        run_id=actual_run_id,
        data_dir=str(data_dir.resolve()),
        output_dir=str(root_output),
        total_sites=len(items),
        succeeded=sum(item.status == "succeeded" for item in items),
        failed=sum(item.status == "failed" for item in items),
        items=items,
    )
    (root_output / "batch-result.json").write_text(
        json.dumps(result.model_dump(mode="json"), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (root_output / "batch-report.md").write_text(_build_markdown(result), encoding="utf-8")
    return result
