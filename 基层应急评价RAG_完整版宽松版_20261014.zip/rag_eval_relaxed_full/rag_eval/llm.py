from __future__ import annotations

import json
import os
import re
from collections.abc import Callable
from typing import Any, TypeVar
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound=BaseModel)
Transport = Callable[[dict[str, Any]], dict[str, Any]]


class DeepSeekClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://api.deepseek.com",
        model: str = "deepseek-v4-pro",
        max_attempts: int = 3,
        timeout_seconds: int = 120,
        transport: Transport | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("DeepSeek API key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.max_attempts = max_attempts
        self.timeout_seconds = timeout_seconds
        self.transport = transport or self._http_transport

    @classmethod
    def from_env(cls, **kwargs: Any) -> "DeepSeekClient":
        return cls(
            api_key=os.environ.get("DEEPSEEK_API_KEY", ""),
            base_url=os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
            model=os.environ.get("DEEPSEEK_MODEL", "deepseek-v4-pro"),
            **kwargs,
        )

    def _http_transport(self, payload: dict[str, Any]) -> dict[str, Any]:
        request = Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urlopen(request, timeout=self.timeout_seconds) as response:
            return json.loads(response.read().decode("utf-8"))

    def complete_json(self, system_prompt: str, user_prompt: str, schema: type[T]) -> T:
        schema_json = json.dumps(schema.model_json_schema(), ensure_ascii=False)
        messages = [
            {
                "role": "system",
                "content": f"{system_prompt}\n请严格返回符合以下 JSON Schema 的 JSON 对象：\nJSON Schema: {schema_json}",
            },
            {"role": "user", "content": user_prompt},
        ]
        last_error: Exception | None = None
        for attempt in range(1, self.max_attempts + 1):
            payload = {
                "model": self.model,
                "messages": messages,
                "response_format": {"type": "json_object"},
                "temperature": 0,
            }
            try:
                response = self.transport(payload)
                content = response["choices"][0]["message"]["content"]
                return schema.model_validate_json(_strip_json_fence(content))
            except HTTPError as exc:
                if exc.code < 500 and exc.code != 429:
                    raise
                last_error = exc
                if attempt >= self.max_attempts:
                    break
            except (URLError, TimeoutError, ConnectionError) as exc:
                last_error = exc
                if attempt >= self.max_attempts:
                    break
            except (KeyError, IndexError, TypeError, json.JSONDecodeError, ValidationError) as exc:
                last_error = exc
                if attempt >= self.max_attempts:
                    break
                messages = messages + [
                    {
                        "role": "user",
                        "content": (
                            "上一次 JSON 输出校验失败。请只返回符合 JSON Schema 的 JSON 对象，"
                            f"不要使用 Markdown。校验失败信息：{exc}"
                        ),
                    }
                ]
        raise RuntimeError(f"DeepSeek did not return valid structured JSON: {last_error}")


def _strip_json_fence(content: str) -> str:
    stripped = content.strip()
    fenced = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", stripped, flags=re.DOTALL | re.IGNORECASE)
    return fenced.group(1) if fenced else stripped
