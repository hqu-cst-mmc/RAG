from __future__ import annotations

import argparse
import json
import sys
import tempfile
from collections import Counter
from datetime import datetime
from pathlib import Path

from .batch import evaluate_batch
from .exporters import site_workbook_filename
from .llm import DeepSeekClient
from .ocr import RapidOCREngine
from .parsers import MaterialParser, parse_materials
from .rubric import load_rubric
from .review import apply_review_results
from .scanner import assess_completeness, scan_materials
from .workflow import EvaluationWorkflow


def default_output_dir(workspace: Path, site_id: str, run_id: str) -> Path:
    return workspace / "outputs" / site_id / run_id


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rag-eval",
        description="基层应急公共服务评价 RAG 命令行工具",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_models = subparsers.add_parser("init-models", help="安装依赖后预下载OCR与中文向量模型")
    init_models.set_defaults(func=run_init_models)

    scan = subparsers.add_parser("scan", help="离线扫描站点材料，不调用大模型")
    scan.add_argument("--site-dir", required=True, type=Path)
    scan.add_argument("--parse", action="store_true", help="同时解析文本材料")
    scan.add_argument("--enable-ocr", action="store_true", help="解析时启用本地图片OCR")
    scan.add_argument("--output-json", type=Path)
    scan.set_defaults(func=run_scan)

    evaluate = subparsers.add_parser("evaluate", help="评价一个已解压站点目录")
    evaluate.add_argument("--site-dir", required=True, type=Path)
    evaluate.add_argument("--site-id", required=True)
    evaluate.add_argument("--site-name")
    evaluate.add_argument("--output-dir", type=Path)
    evaluate.add_argument("--resume-run-id")
    evaluate.add_argument("--allow-sensitive-upload", action="store_true")
    evaluate.add_argument("--disable-vector", action="store_true")
    evaluate.add_argument("--disable-ocr", action="store_true")
    evaluate.set_defaults(func=run_evaluate)

    evaluate_batch_parser = subparsers.add_parser(
        "evaluate-batch",
        help="批量评价多站点目录中的全部站点",
    )
    evaluate_batch_parser.add_argument("--data-dir", required=True, type=Path)
    evaluate_batch_parser.add_argument("--output-dir", type=Path)
    evaluate_batch_parser.add_argument("--allow-sensitive-upload", action="store_true")
    evaluate_batch_parser.add_argument("--disable-vector", action="store_true")
    evaluate_batch_parser.add_argument("--disable-ocr", action="store_true")
    evaluate_batch_parser.add_argument(
        "--flat-sites",
        action="store_true",
        help="将 --data-dir 下的第一层文件夹直接视为站点；适用于 data/需要分析的资料/<站点>/",
    )
    evaluate_batch_parser.set_defaults(func=run_evaluate_batch)

    apply_review = subparsers.add_parser(
        "apply-review",
        help="读取人工复核Excel并回写分值、重算指数、重新导出结果",
    )
    apply_review.add_argument("--review-dir", required=True, type=Path)
    apply_review.add_argument("--source-output-dir", required=True, type=Path)
    apply_review.add_argument("--output-dir", required=True, type=Path)
    apply_review.set_defaults(func=run_apply_review)
    return parser


def run_init_models(_args: argparse.Namespace) -> int:
    try:
        print("初始化 RapidOCR...")
        RapidOCREngine()._load()
        print("下载中文向量模型 BAAI/bge-small-zh-v1.5...")
        from fastembed import TextEmbedding

        embedder = TextEmbedding(model_name="BAAI/bge-small-zh-v1.5")
        list(embedder.embed(["基层应急公共服务评价模型初始化"]))
        with tempfile.TemporaryDirectory(prefix="rag-eval-qdrant-") as temp_dir:
            from qdrant_client import QdrantClient

            QdrantClient(path=temp_dir).close()
    except ImportError as exc:
        print(
            "缺少完整依赖。请先运行：python -m pip install -e \".[full]\"\n"
            f"详细信息：{exc}",
            file=sys.stderr,
        )
        return 1
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print("OCR与向量模型已准备完成。")
    return 0


def run_scan(args: argparse.Namespace) -> int:
    materials = scan_materials(args.site_dir)
    payload: dict = {
        "site_dir": str(args.site_dir.resolve()),
        "materials": [item.model_dump(mode="json") for item in materials],
        "counts_by_extension": dict(Counter(item.extension or "<none>" for item in materials)),
        "duplicate_files": sum(item.duplicate_of is not None for item in materials),
    }
    if args.parse:
        chunks, materials = parse_materials(
            args.site_dir,
            materials,
            MaterialParser(enable_ocr=args.enable_ocr),
        )
        completeness = assess_completeness(materials, load_rubric())
        payload.update(
            {
                "materials": [item.model_dump(mode="json") for item in materials],
                "chunks": len(chunks),
                "completeness": completeness.model_dump(mode="json"),
            }
        )
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(text, encoding="utf-8")
        print(f"扫描结果已写入：{args.output_json.resolve()}")
    else:
        print(text)
    return 0


def run_evaluate(args: argparse.Namespace) -> int:
    if not args.allow_sensitive_upload:
        print(
            "站点材料可能包含姓名、手机号等敏感信息。云端评价前必须显式添加 "
            "--allow-sensitive-upload。",
            file=sys.stderr,
        )
        return 2
    run_id = args.resume_run_id or datetime.now().strftime("%Y%m%d-%H%M%S")
    output_dir = args.output_dir or default_output_dir(Path.cwd(), args.site_id, run_id)
    try:
        llm = DeepSeekClient.from_env()
        workflow = EvaluationWorkflow(
            llm=llm,
            enable_vector=not args.disable_vector,
            enable_ocr=not args.disable_ocr,
            progress=print,
        )
        state = workflow.evaluate(
            site_dir=args.site_dir,
            site_id=args.site_id,
            site_name=args.site_name,
            output_dir=output_dir,
            allow_sensitive_upload=True,
            run_id=run_id,
            resume_run_id=args.resume_run_id,
        )
    except Exception as exc:
        print(f"评价失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(f"评价完成：{state.profile.site_name}")
    print(f"报告：{(output_dir / 'report.md').resolve()}")
    print(f"Excel：{(output_dir / site_workbook_filename(state.profile.site_id)).resolve()}")
    print(f"JSON：{(output_dir / 'result.json').resolve()}")
    return 0


def run_evaluate_batch(args: argparse.Namespace) -> int:
    if not args.allow_sensitive_upload:
        print(
            "站点材料可能包含姓名、手机号等敏感信息。云端批量评价前必须显式添加 "
            "--allow-sensitive-upload。",
            file=sys.stderr,
        )
        return 2
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S")
    output_dir = args.output_dir or Path.cwd() / "outputs" / "_batch" / run_id
    try:
        llm = DeepSeekClient.from_env()

        def evaluator(site_dir: Path, site_id: str, site_name: str, site_output_dir: Path) -> None:
            workflow = EvaluationWorkflow(
                llm=llm,
                enable_vector=not args.disable_vector,
                enable_ocr=not args.disable_ocr,
                progress=lambda message: print(f"[{site_id}] {message}"),
            )
            workflow.evaluate(
                site_dir=site_dir,
                site_id=site_id,
                site_name=site_name,
                output_dir=site_output_dir,
                allow_sensitive_upload=True,
                run_id=run_id,
            )

        result = evaluate_batch(
            data_dir=args.data_dir,
            output_dir=output_dir,
            evaluator=evaluator,
            progress=print,
            run_id=run_id,
            flat_sites=args.flat_sites,
        )
    except Exception as exc:
        print(f"批量评价失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(f"批量评价完成：总计 {result.total_sites}，成功 {result.succeeded}，失败 {result.failed}")
    print(f"批次报告：{(output_dir / 'batch-report.md').resolve()}")
    print(f"批次JSON：{(output_dir / 'batch-result.json').resolve()}")
    return 1 if result.failed else 0


def run_apply_review(args: argparse.Namespace) -> int:
    try:
        result = apply_review_results(
            review_dir=args.review_dir,
            source_output_dir=args.source_output_dir,
            output_dir=args.output_dir,
        )
    except Exception as exc:
        print(f"人工复核回写失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(
        "人工复核回写完成："
        f"复核文件 {result.reviewed_files}，应用记录 {result.applied_updates}，改变分值 {result.changed_scores}"
    )
    print(f"回写报告：{(args.output_dir / 'apply-review-report.md').resolve()}")
    print(f"回写JSON：{(args.output_dir / 'apply-review-result.json').resolve()}")
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))
