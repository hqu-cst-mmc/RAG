from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from openpyxl import load_workbook
from pydantic import BaseModel, Field
from .exporters import export_run
from .models import RunState
from .rubric import load_rubric
from .rules import FUZZY_VALUES, calculate_indices
REVIEW_SHEET_NAME = '人工复核清单'
REVIEW_RESULT_COLUMN = '复核结果'
INDICATOR_COLUMN = '指标编号'
NEGATIVE_MARKERS = ('没有', '无材料', '无记录', '无报告', '未找到', '不支持', '不存在', '缺少')
POSITIVE_MARKERS = ('有材料', '有记录', '有报告', '有转移记录')

class ReviewUpdate(BaseModel):
    site_id: str
    indicator_id: str
    previous_score: int
    new_score: int
    delta: int
    review_result: str

class ReviewApplyResult(BaseModel):
    review_dir: str
    source_output_dir: str
    output_dir: str
    reviewed_files: int = 0
    applied_updates: int = 0
    changed_scores: int = 0
    skipped_files: list[str] = Field(default_factory=list)
    updates: list[ReviewUpdate] = Field(default_factory=list)

def review_score_delta(value: Any) -> int:
    text = str(value or '').strip()
    if not text:
        return 0
    compact = ''.join(text.split())
    if any((marker in compact for marker in NEGATIVE_MARKERS)):
        return 0
    if '详细' in compact:
        return 2
    if any((marker in compact for marker in POSITIVE_MARKERS)):
        return 1
    if compact.startswith('有'):
        return 1
    return 0

def _append_reason(existing: str, message: str) -> str:
    return f'{existing}；{message}' if existing else message

def _find_source_result(source_output_dir: Path, site_id: str) -> Path | None:
    direct = source_output_dir / site_id / 'result.json'
    if direct.exists():
        return direct
    matches = sorted(source_output_dir.glob(f'*/{site_id}/result.json'))
    return matches[0] if matches else None

def _read_review_rows(path: Path) -> list[tuple[str, str]]:
    workbook = load_workbook(path, read_only=True, data_only=True)
    if REVIEW_SHEET_NAME not in workbook.sheetnames:
        return []
    sheet = workbook[REVIEW_SHEET_NAME]
    rows = sheet.iter_rows(values_only=True)
    try:
        headers = [str(value or '').strip() for value in next(rows)]
    except StopIteration:
        return []
    if INDICATOR_COLUMN not in headers or REVIEW_RESULT_COLUMN not in headers:
        return []
    indicator_index = headers.index(INDICATOR_COLUMN)
    review_index = headers.index(REVIEW_RESULT_COLUMN)
    review_rows: list[tuple[str, str]] = []
    for row in rows:
        indicator_id = str(row[indicator_index] or '').strip() if len(row) > indicator_index else ''
        review_result = str(row[review_index] or '').strip() if len(row) > review_index else ''
        if indicator_id and review_result:
            review_rows.append((indicator_id, review_result))
    return review_rows

def _apply_site_reviews(state: RunState, site_id: str, rows: list[tuple[str, str]]) -> list[ReviewUpdate]:
    updates: list[ReviewUpdate] = []
    for indicator_id, review_result in rows:
        if indicator_id not in state.scores or not indicator_id.startswith('C'):
            continue
        try:
            number = int(indicator_id[1:])
        except ValueError:
            continue
        if number < 1 or number > 38:
            continue
        delta = review_score_delta(review_result)
        if delta <= 0:
            continue
        score = state.scores[indicator_id]
        previous = int(score.raw_score or 0)
        new_score = min(3, previous + delta)
        score.raw_score = new_score
        score.fuzzy_score = FUZZY_VALUES[new_score]
        score.needs_review = True
        score.reason = _append_reason(score.reason, f'人工复核回写：复核结果“{review_result}”，按规则加{delta}分，{previous}分调整为{new_score}分')
        score.confidence = '高' if new_score > previous else score.confidence
        state.warnings.append(f'人工复核回写：{indicator_id} {previous}->{new_score}；复核结果：{review_result}')
        updates.append(ReviewUpdate(site_id=site_id, indicator_id=indicator_id, previous_score=previous, new_score=new_score, delta=delta, review_result=review_result))
    return updates

def _export_reviewed_state(state: RunState, site_output_dir: Path) -> None:
    state.output_dir = str(site_output_dir.resolve())
    export_run(state, site_output_dir)
    (site_output_dir / 'checkpoint.json').write_text(json.dumps(state.model_dump(mode='json'), ensure_ascii=False, indent=2), encoding='utf-8')

def _write_summary(result: ReviewApplyResult) -> None:
    output_dir = Path(result.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / 'apply-review-result.json').write_text(result.model_dump_json(indent=2), encoding='utf-8')
    lines = ['# 人工复核回写结果', '', f'- 复核文件数：{result.reviewed_files}', f'- 应用复核记录：{result.applied_updates}', f'- 实际改变分值：{result.changed_scores}', '', '| 站点 | 指标 | 原分值 | 新分值 | 加分 | 复核结果 |', '| --- | --- | --- | --- | --- | --- |']
    lines.extend((f'| {item.site_id} | {item.indicator_id} | {item.previous_score} | {item.new_score} | {item.delta} | {item.review_result} |' for item in result.updates))
    if result.skipped_files:
        lines.extend(['', '## 跳过文件', ''])
        lines.extend((f'- {item}' for item in result.skipped_files))
    (output_dir / 'apply-review-report.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')

def apply_review_results(*, review_dir: Path, source_output_dir: Path, output_dir: Path) -> ReviewApplyResult:
    result = ReviewApplyResult(review_dir=str(review_dir.resolve()), source_output_dir=str(source_output_dir.resolve()), output_dir=str(output_dir.resolve()))
    rubric = load_rubric()
    output_dir.mkdir(parents=True, exist_ok=True)
    for review_file in sorted(review_dir.glob('*.xlsx')):
        if review_file.name.startswith('~$'):
            continue
        result.reviewed_files += 1
        site_id = review_file.stem
        source_result = _find_source_result(source_output_dir, site_id)
        if source_result is None:
            result.skipped_files.append(f'{review_file.name}：未找到原始 result.json')
            continue
        state = RunState.model_validate_json(source_result.read_text(encoding='utf-8'))
        site_output_dir = output_dir / site_id
        rows = _read_review_rows(review_file)
        if not rows:
            _export_reviewed_state(state, site_output_dir)
            result.skipped_files.append(f'{review_file.name}：未找到非空复核结果')
            continue
        updates = _apply_site_reviews(state, site_id, rows)
        if not updates:
            _export_reviewed_state(state, site_output_dir)
            result.skipped_files.append(f'{review_file.name}：复核结果未触发加分规则')
            continue
        state.indices = calculate_indices(state.scores, rubric, sb=state.c39.reference_value if state.c39 and state.c39.usable_as_external_reference else None)
        _export_reviewed_state(state, site_output_dir)
        result.updates.extend(updates)
        result.applied_updates += len(updates)
        result.changed_scores += sum((item.new_score != item.previous_score for item in updates))
    _write_summary(result)
    return result
