from __future__ import annotations

import json
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, TypedDict

from pydantic import BaseModel, Field

from .c39 import collect_official_score_candidates, extract_official_grade
from .exporters import export_run
from .models import C39Result, EvidenceItem, RunState, ScoreItem, SiteProfile
from .parsers import MaterialParser, parse_materials
from .retrieval import HybridRetriever
from .rubric import load_rubric
from .rules import apply_score_caps, calculate_indices, classify_c39, normalize_scores
from .scanner import assess_completeness, find_reference_rule_documents, scan_materials


class SiteProfileDraft(BaseModel):
    scenario_type: str = "不确定"
    major_risks: list[str] = Field(default_factory=list)
    explanation: str = ""


class EvidenceBatch(BaseModel):
    items: list[EvidenceItem]


class ScoreBatch(BaseModel):
    items: list[ScoreItem]


class C39Draft(BaseModel):
    official_score: float | None = None
    max_score: float | None = None
    official_grade: str | None = None
    materials_detailed: bool = False
    explanation: str = ""


class C39TableSelectionDraft(BaseModel):
    selected_candidate_id: str | None = None
    explanation: str = ""


class GraphPayload(TypedDict):
    run_state: RunState


class EvaluationWorkflow:
    NODE_NAMES = ["scan", "profile", "evidence", "score", "caps", "c39", "indices", "export"]

    def __init__(
        self,
        *,
        llm: Any,
        enable_vector: bool = True,
        enable_ocr: bool = True,
        llm_workers: int = 1,
        prefer_langgraph: bool = True,
        progress: Callable[[str], None] | None = None,
    ) -> None:
        self.llm = llm
        self.rubric = load_rubric()
        self.enable_vector = enable_vector
        self.enable_ocr = enable_ocr
        if llm_workers < 1:
            raise ValueError("llm_workers must be positive")
        self.llm_workers = llm_workers
        self.node_names = list(self.NODE_NAMES)
        self.prefer_langgraph = prefer_langgraph
        self.progress = progress
        self.output_dir: Path | None = None
        self._retriever: HybridRetriever | None = None

    def evaluate(
        self,
        *,
        site_dir: Path,
        site_id: str,
        output_dir: Path,
        allow_sensitive_upload: bool,
        site_name: str | None = None,
        run_id: str | None = None,
        resume_run_id: str | None = None,
    ) -> RunState:
        if not allow_sensitive_upload:
            raise ValueError("Cloud evaluation requires explicit --allow-sensitive-upload consent")
        reference_rules = find_reference_rule_documents(site_dir)
        if reference_rules:
            names = "、".join(path.name for path in reference_rules)
            raise ValueError(
                f"站点评价目录中包含规则文档《{names}》。"
                "请将 --site-dir 指向单个评价单元目录，不要使用包含多县区材料和评价赋值大纲的 data 根目录。"
            )
        self.output_dir = output_dir.resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        checkpoint = self.output_dir / "checkpoint.json"
        if resume_run_id and checkpoint.exists():
            state = RunState.model_validate_json(checkpoint.read_text(encoding="utf-8"))
        else:
            actual_run_id = run_id or resume_run_id or datetime.now().strftime("%Y%m%d-%H%M%S")
            state = RunState(
                run_id=actual_run_id,
                model_name=getattr(self.llm, "model", "unknown"),
                site_dir=str(site_dir.resolve()),
                output_dir=str(self.output_dir),
                profile=SiteProfile(site_id=site_id, site_name=site_name or site_dir.name),
            )
        try:
            if self.prefer_langgraph and not state.completed_nodes:
                try:
                    return self._run_langgraph(state)
                except ImportError:
                    state.warnings.append("LangGraph未安装，已使用等价顺序工作流。安装full依赖后可启用LangGraph。")
            return self._run_sequential(state)
        finally:
            if self._retriever is not None:
                self._retriever.close()

    def _run_langgraph(self, state: RunState) -> RunState:
        from langgraph.graph import END, START, StateGraph
        from langgraph.checkpoint.sqlite import SqliteSaver

        graph = StateGraph(GraphPayload)
        for node_name in self.node_names:
            graph.add_node(node_name, self._graph_node(node_name))
        graph.add_edge(START, self.node_names[0])
        for left, right in zip(self.node_names, self.node_names[1:]):
            graph.add_edge(left, right)
        graph.add_edge(self.node_names[-1], END)
        database = Path(state.output_dir) / "langgraph-checkpoints.sqlite"
        connection = sqlite3.connect(database, check_same_thread=False)
        try:
            compiled = graph.compile(checkpointer=SqliteSaver(connection))
            result = compiled.invoke(
                {"run_state": state},
                config={"configurable": {"thread_id": state.run_id}},
            )
            return result["run_state"]
        finally:
            connection.close()

    def _graph_node(self, node_name: str):
        def invoke(payload: GraphPayload) -> GraphPayload:
            state = payload["run_state"]
            self._execute_node(node_name, state)
            return {"run_state": state}

        return invoke

    def _run_sequential(self, state: RunState) -> RunState:
        for node_name in self.node_names:
            if node_name not in state.completed_nodes:
                self._execute_node(node_name, state)
        return state

    def _execute_node(self, node_name: str, state: RunState) -> None:
        getattr(self, f"_node_{node_name}")(state)
        state.completed_nodes.append(node_name)
        self._save_checkpoint(state)
        if node_name == "export":
            export_run(state, Path(state.output_dir))

    def _save_checkpoint(self, state: RunState) -> None:
        assert self.output_dir is not None
        (self.output_dir / "checkpoint.json").write_text(
            json.dumps(state.model_dump(mode="json"), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _report(self, message: str) -> None:
        if self.progress is not None:
            self.progress(message)

    def _node_scan(self, state: RunState) -> None:
        self._report("[1/8] 扫描材料目录...")
        output = Path(state.output_dir)
        materials = scan_materials(Path(state.site_dir))
        self._report(f"[1/8] 发现 {len(materials)} 个材料，开始解析和可选OCR...")
        parser = MaterialParser(enable_ocr=self.enable_ocr, ocr_cache_dir=output / ".ocr-cache")
        chunks, parsed = parse_materials(
            Path(state.site_dir),
            materials,
            parser,
            progress=lambda current, total, item: self._report(
                f"[1/8] 解析进度 {current}/{total}：{item.relative_path} [{item.status}]"
            )
            if current == 1 or current == total or current % 10 == 0
            else None,
        )
        completeness = assess_completeness(parsed, self.rubric)
        state.materials = parsed
        state.chunks = chunks
        state.profile.completeness = completeness.level
        state.profile.completeness_reason = completeness.reason
        state.profile.aspects = completeness.aspects
        for material in parsed:
            if material.error:
                state.warnings.append(f"材料解析失败：{material.relative_path}：{material.error}")

    def _node_profile(self, state: RunState) -> None:
        self._report("[2/8] 生成站点概况...")
        draft = self.llm.complete_json(
            "你是基层应急公共服务供给评价编码助手。只依据输入材料概括站点，不赋分。",
            json.dumps(
                {
                    "site_name": state.profile.site_name,
                    "allowed_scenario_types": self.rubric.scenarios,
                    "materials": [item.relative_path for item in state.materials[:200]],
                    "sample_text": [chunk.text for chunk in state.chunks[:40]],
                },
                ensure_ascii=False,
            ),
            SiteProfileDraft,
        )
        state.profile.scenario_type = draft.scenario_type if draft.scenario_type in self.rubric.scenarios else "不确定"
        state.profile.major_risks = draft.major_risks
        state.profile.has_official_assessment = any(item.material_type == "官方考核表" for item in state.materials)

    def _build_retriever(self, state: RunState) -> HybridRetriever:
        if self._retriever is not None:
            return self._retriever
        try:
            self._retriever = HybridRetriever(
                state.chunks,
                enable_vector=self.enable_vector,
                storage_path=Path(state.output_dir) / ".qdrant" if self.enable_vector else None,
            )
        except RuntimeError as exc:
            state.warnings.append(f"向量检索未启用：{exc} 已回退关键词检索。")
            self._retriever = HybridRetriever(state.chunks, enable_vector=False)
        return self._retriever

    def _node_evidence(self, state: RunState) -> None:
        retriever = self._build_retriever(state)
        groups = list(self.rubric.secondary_groups.items())
        jobs = []
        for index, (group_id, indicator_ids) in enumerate(groups, start=1):
            self._report(f"[3/8] 证据提取 {index}/{len(groups)}：{group_id}")
            definitions = [self.rubric.indicators[indicator_id] for indicator_id in indicator_ids]
            query = " ".join(definition.name for definition in definitions)
            contexts = [
                {
                    "source": f"{result.chunk.relative_path}：{result.chunk.locator}",
                    "material_type": result.chunk.material_type,
                    "text": result.chunk.text,
                }
                for result in retriever.retrieve(query, limit=14)
            ]
            jobs.append((group_id, indicator_ids, (
                "这是宽松酌情评分版。优先提取材料中明确出现的内容；同时允许把文件名、照片文字、活动名称、"
                "场景内容与指标之间的弱关联作为辅助证据。不得虚构具体台账、制度名称、人员名单或反馈结果。"
                "如果只有照片或活动名称能弱关联到某指标，将found设为不确定、strength设为弱，并在摘要中写明弱关联依据。"
                "完全无关或明确不存在时才设为否。逐项返回输入指标，并说明需补材料。",
                json.dumps(
                    {
                        "group": group_id,
                        "indicators": [definition.model_dump() for definition in definitions],
                        "contexts": contexts,
                    },
                    ensure_ascii=False,
                ),
                EvidenceBatch,
            )))
        for group_id, indicator_ids, batch in self._complete_group_jobs(jobs):
            self._require_exact_ids(group_id, indicator_ids, [item.indicator_id for item in batch.items])
            state.evidence.update({item.indicator_id: item for item in batch.items})

    def _node_score(self, state: RunState) -> None:
        groups = list(self.rubric.secondary_groups.items())
        jobs = []
        for index, (group_id, indicator_ids) in enumerate(groups, start=1):
            self._report(f"[4/8] 初步赋值 {index}/{len(groups)}：{group_id}")
            definitions = [self.rubric.indicators[indicator_id] for indicator_id in indicator_ids]
            jobs.append((group_id, indicator_ids, (
                "这是宽松酌情评分版。基于已经提取的证据，对C1-C38进行0-3分初步赋值。每项必须返回0、1、2或3，不得返回null或NA。"
                "0分：材料完全没有相关内容、明显无关，或材料明确表明该指标不存在。"
                "1分：存在零散表现、弱关联表现或间接关联表现，例如一般性表述、相关工作、临时安排、单次活动、单一照片、"
                "文件名或照片文字能说明开展过相关场景。对于学校消防应急疏散演练这类材料，可酌情弱关联到演练组织、"
                "安全宣传、应急准备、场景适配等相关指标，但必须标明证据弱、需人工复核。"
                "2分：存在较清晰的制度安排、责任分工、台账记录或运行表现，并在关键环节发挥作用。"
                "3分：存在制度安排、运行记录、反馈修正和稳定价值结果，形成较完整闭环。"
                "只要材料提到相关工作、相关活动、相关场景，或能弱关联到该指标背后的必要准备工作，即使证据零散，也应至少给1分。"
                "但2分和3分仍必须依赖较直接的制度、台账、记录、反馈或闭环证据，不得仅凭照片推高。"
                "只允许引用输入证据。官方考核高分只能影响C39，不能直接推高C1-C38。",
                json.dumps(
                    {
                        "group": group_id,
                        "indicators": [definition.model_dump() for definition in definitions],
                        "evidence": [state.evidence[indicator_id].model_dump() for indicator_id in indicator_ids],
                    },
                    ensure_ascii=False,
                ),
                ScoreBatch,
            )))
        for group_id, indicator_ids, batch in self._complete_group_jobs(jobs):
            self._require_exact_ids(group_id, indicator_ids, [item.indicator_id for item in batch.items])
            state.scores.update({item.indicator_id: item for item in batch.items})

    def _complete_group_jobs(self, jobs):
        """Only independent model calls run concurrently; prompts and scoring stay unchanged."""
        def complete(job):
            group_id, indicator_ids, arguments = job
            result = self.llm.complete_json(*arguments)
            self._report(f"模型响应完成：{group_id} ({arguments[2].__name__})")
            return group_id, indicator_ids, result

        if self.llm_workers == 1:
            return [complete(job) for job in jobs]
        with ThreadPoolExecutor(max_workers=self.llm_workers) as executor:
            return list(executor.map(complete, jobs))

    def _node_caps(self, state: RunState) -> None:
        self._report("[5/8] 应用谨慎封顶规则...")
        state.scores, state.rule_hits = apply_score_caps(state.scores, state.evidence)

    def _node_c39(self, state: RunState) -> None:
        self._report("[6/8] 处理C39标准化建设基础指标...")
        score_candidates = collect_official_score_candidates(Path(state.site_dir), state.materials)
        extracted = score_candidates[0].as_extraction() if len(score_candidates) == 1 else None
        selection_note = ""
        if len(score_candidates) > 1:
            selection = self.llm.complete_json(
                "当前材料中存在多张具备评分结构的官方表格。"
                "你只负责选择适用于当前乡镇或街道应急管理站评价对象的候选表，不得计算、修改或推断分数。"
                "候选表可能来自同一文件的不同附件，例如乡镇街道附件和村社区附件。"
                "请结合站点名称、候选表标题、附件序号和内容摘要选择唯一candidate_id。"
                "如果无法唯一判断，将selected_candidate_id设为null并说明原因。",
                json.dumps(
                    {
                        "site_id": state.profile.site_id,
                        "site_name": state.profile.site_name,
                        "evaluation_object": "乡镇或街道基层应急管理站",
                        "candidates": [
                            {
                                "candidate_id": candidate.candidate_id,
                                "source": candidate.source,
                                "table_index": candidate.table_index,
                                "title": candidate.title,
                                "preview": candidate.preview,
                            }
                            for candidate in score_candidates
                        ],
                    },
                    ensure_ascii=False,
                ),
                C39TableSelectionDraft,
            )
            chosen = next(
                (
                    candidate
                    for candidate in score_candidates
                    if candidate.candidate_id == selection.selected_candidate_id
                ),
                None,
            )
            if chosen is None:
                state.c39 = C39Result(
                    status="多附件评分表待人工复核",
                    usable_as_external_reference=False,
                    notes=(
                        "材料中存在多张具备评分结构的官方表格，模型未能唯一确认适用于当前站点的附件。"
                        f"模型说明：{selection.explanation or '未提供说明。'}"
                    ),
                )
                state.profile.has_official_result = False
                return
            extracted = chosen.as_extraction()
            selection_note = (
                f" 模型选表：{chosen.source} 第{chosen.table_index}张表；"
                f"选择理由：{selection.explanation or '未提供说明。'}"
            )
        if extracted is not None:
            state.c39 = classify_c39(
                official_score=extracted.official_score,
                max_score=extracted.max_score,
            )
            method = "显式总分" if extracted.method == "explicit_total" else "官方小计列汇总"
            state.c39.notes = (
                f"{state.c39.notes} 来源：{extracted.source}；计算依据：{method}。{selection_note}"
            )
            state.profile.has_official_result = True
            return
        extracted_grade = extract_official_grade(Path(state.site_dir), state.materials)
        if extracted_grade is not None:
            state.c39 = classify_c39(official_grade=extracted_grade.official_grade)
            state.c39.notes = (
                f"{state.c39.notes} 来源：{extracted_grade.source}；"
                "计算依据：官方综合评价勾选等级。"
            )
            state.profile.has_official_result = True
            return
        retriever = self._build_retriever(state)
        contexts = [
            {
                "source": f"{result.chunk.relative_path}：{result.chunk.locator}",
                "text": result.chunk.text,
            }
            for result in retriever.retrieve("官方评价表 验收表 考核表 总分 等级 优秀 良好 合格", limit=16)
        ]
        draft = self.llm.complete_json(
            "单独处理C39。只提取材料明确出现的官方分数、满分或官方等级；不得自行推算或假设满分。"
            "如发现实际得分但材料未明确出现满分，保留official_score并将max_score设为null。"
            "没有验收表但材料翔实时只标记materials_detailed。",
            json.dumps({"materials": [item.relative_path for item in state.materials], "contexts": contexts}, ensure_ascii=False),
            C39Draft,
        )
        state.c39 = classify_c39(
            official_score=draft.official_score,
            max_score=draft.max_score,
            official_grade=draft.official_grade,
            materials_detailed=draft.materials_detailed,
        )
        state.profile.has_official_result = state.c39.usable_as_external_reference

    def _node_indices(self, state: RunState) -> None:
        self._report("[7/8] 计算B1-B11、PV和MC...")
        # Normalize again so checkpoints produced by older versions cannot export C1-C38 as NA.
        state.scores = normalize_scores(state.scores, state.evidence)
        state.indices = calculate_indices(
            state.scores,
            self.rubric,
            sb=state.c39.reference_value if state.c39 and state.c39.usable_as_external_reference else None,
        )

    def _node_export(self, state: RunState) -> None:
        self._report("[8/8] 导出报告、Excel和JSON...")
        # Export after marking this node complete so result.json matches checkpoint.json.
        return None

    @staticmethod
    def _require_exact_ids(group_id: str, expected: list[str], actual: list[str]) -> None:
        if sorted(expected) != sorted(actual) or len(actual) != len(set(actual)):
            raise RuntimeError(f"{group_id} structured output indicator mismatch: expected {expected}, received {actual}")
